﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Windows;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Timers;
using System.IO;
using System.Runtime.Remoting.Messaging;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//using Microsoft.Office.Interop.Excel;
//using Agilent.CommandExpert.ScpiNet.Ag90x0_VMA_A_30_00;

//    TX_BPSK_MODE = 0,	                    //!<		XT9000 Tx BPSK mode			    0
// 		TX_QPSK_MODE,                       //!<		XT9000 Tx QPSK mode			    1
// 		TX_oQPSK_MODE,          			//!<		XT9000 Tx oQPSK mode	        2
// 		TX_FSK_MODE,            			//!<		XT9000 Tx FSK mode	            3
// 		TX_GFSK_MODE,           			//!<		XT9000 Tx GFSK mode	            4
namespace TC06Test
{

    public partial class MainForm : Form, IView
    {
        //public event EventHandler SelectedIndexChanged; // Owen Listview Test1
        private System.Timers.Timer aTimer;
        private System.Timers.Timer readRegTimer;
        private System.Timers.Timer checkSCPITimer;
        private delegate void DelShowMessage(string sMessage, Color sColor, float cur);
        private delegate void DelShowRxLog(string str);
        private delegate void DelGetDataRightNow(string str, int mode);
   
        private delegate void DelShowRxRcvNum(string sNum, string sRssi);
        private delegate void DelDisableSetting();

        private Controller txSerial;
        private Controller2 rxSerial;
        private Controller3 pcbSerial;
        private string initTitle = "ER41xx TEST TOOL";
        RegIDs          regIDs;
        RegNames        regNames;
        RegContents     regContents;
        FsPos           fsPos;
        FSMask          fsMask;
        BitRange        bitRange;
        public bool isRxOldMethod = false;
        public int TX_BPSK_MODE     = 0;
        public int TX_QPSK_MODE     = 1;
        public int TX_oQPSK_MODE    = 2;
        public int TX_FSK_MODE      = 3;
        public int TX_GFSK_MODE     = 4;
        public int baudRateNumber = 115200;
        //public bool comConnect = false;       	
        public string revisionReg = "f104";
        public bool isTableReadReg  = false;
        public bool isWaitingData   = false;
        public bool isGetBackData   = false;
        public bool isShowIOData    = false;
        public bool isAutoFreqCal2  = false;
        public string readBackData;
        public bool bSearchID;
        public bool bSearchReg;

        public bool rxTestMode = false;
        public int rxReceivedNum = 0;
        public int cwProcess;
        public float freqTxt;
        public int powerTxt;
        public bool isRxSenStart;
        public int txPacketSetNum = 0;
        public int txPacketSent = 0;

        public int totalRssi = 0;
        public int avgRssi = 0;
        public int nowRssi = 0;
        public int ckRxSenResult = 0;
        public int formWidth = 1820;
        public int formHeight = 900;

        public int txMeter = 0;
        private bool meterGetPower = false;

        private int ckTxTimes = 0;

        public bool isReadAllRegister;
        public bool isReadRegister;
        public bool isRSSIAnalysis;
        public string[] regName = new string[345];
        public string[] regList = new string[345];
        public string[] regValue = new string[345];
        public uint[] regValueInt = new uint[345];
        public string[][] regCont;
        public string[][] bitRangeMatrix;
        public int[][] fsPosMatrix;
        public int[][] fsMaskMatrix;
        public int regTableSize;
        public ListViewItem viewItem;
        public int rcvIdx;
        public int rcvEnd;
        public byte[] rcvRegArray = new byte[450];  // ORG: [4500]
        public int selIdx;
        public int[] searchIdx;
        public List<int> searchRegName = new List<int>();
        //public string[] drList = { "2000000", "1000000", "500000", "100000", "50000", "12500"};
        public string[] drList = {"2000.000","1600.000","1250.000","1000.000","800.000","625.000","500.000",
                                "400.000","320.000","312.500","250.000","200.000","160.000","156.250",
                                "125.000","100.000","80.000","78.125","64.000","62.500","50.000","40.000",
                                "32.000","31.250","25.000","20.000","16.000","15.625","12.800","12.500",
                                "10.000","8.000","6.400","6.250","5.000","4.000","3.200","3.125","2.560",
                                "2.500","2.000","1.600","1.280","1.250" };
        public string[] drList2 = {"2000000","1600000","1250000","1000000","800000","625000","500000",
                                "400000","320000","312500","250000","200000","160000","156250",
                                "125000","100000","80000","78125","64000","62500","50000","40000",
                                "32000","31250","25000","20000","16000","15625","12800","12500",
                                "10000","8000","6400","6250","5000","4000","3200","3125","2560",
                                "2500","2000","1600","1280","1250" };
        public string[] powerList = {"0","1","2","3","4","5","6","7","8","9","10","11","12",
                                    "13","14","15","16","17","18","19","20","21","22","23"};
        public string[] LowpowerList = {"0","1","2","3","4","5","6","7","8","9","10","11","12",
                                    "13","14"};
        /*
        public string[] powerLevelList = {"6","7","8","9","10","11","12","14","15","17","20","22","25",
                                    "28","32","37","43","49","58","69","87","114","123","127"};*/
        /*
        public string[] powerLevelList = {"5","6","7","8","9","10","11","13","15","16","18","21","24",
                                    "27","30","34","39","43","50","59","68","87","115","127"}; */

        public string[] powerLevelList = {"5","6","7","8","9","10","11","12","14","15","18","20","22",
                                    "25","29","33","37","47","51","61","81","114","127","127"};
        public string[] LowpowerLevelList = {"3","4","5","6","7","8","9","10","11","12","14","16","19",
                                    "22","27","27","27","27","27","27","27","27","27","27"};
              
        public string[] modList = { "GFSK" };
        public string[] modIdxList = { "0.5", "1", "2", "4" };
        //public string[] pwrList = { "23" };
        //TreeNode myTreeNode;
        public MainForm()
        {
            InitializeComponent();
            InitializeCOMCombox();
            TxComRefresh();
            RxComRefresh();
            ModeComRefresh();
            InitialPowerList();
            InitialTxDatarate();
            InitialRxDatarate();
            InitialTxMod();
            InitialRxMod();
            //InitialTxModIdx(modIdxList.Length);
            InitialRxModIdx(modIdxList.Length);
            //InitialTxPwr();
            modeSelectCombobox.SelectedIndex = 0;
            this.rxTestPage.Parent = null;//隱藏
            this.modePage.Parent = null;//隱藏

            powerTxt = 0;
            freqTxt = 0;
            cwProcess = 0;

            selIdx = 0;
            rcvIdx = 0;
            rcvEnd = 0;
            regTableSize = 0;
            isRxSenStart = false;
            bSearchID = false;
            bSearchReg = false;
            FullInSearchRegName();
            isReadAllRegister   = false;
            isReadRegister      = false;
            isRSSIAnalysis = false;
            viewItem    = new ListViewItem();
            regContents = new RegContents();
            fsPos       = new FsPos();
            fsMask      = new FSMask();
            bitRange    = new BitRange();
            //listView1.View = View.Details;  // OWen closed at 2025/03/25
            //TableCreate();            // OWen closed at 2025/03/25
            //RegisterIDList();         // OWen closed at 2025/03/25    
            //RegisterNameList();       // OWen closed at 2025/03/25
            //ShowRegister();           // OWen closed at 2025/03/25
            /*  // OWen closed at 2025/03/25
            regCont = new string[345][];          
            fsPosMatrix     = new int[345][];
            fsMaskMatrix    = new int[345][];
            bitRangeMatrix  = new string[345][];
            regCont         = regContents.getRegContentList();
            fsPosMatrix     = fsPos.getfsPos();
            fsMaskMatrix    = fsMask.getfsMask();
            bitRangeMatrix  = bitRange.getbitRange();
            listView1.SelectedIndexChanged  += ListView1_SelectedIndexChanged;
            dataGridView1.CellEndEdit += DataGridView1_AfterEdit;
            //this.treeView1.AfterSelect      += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft JhengHei", 13);
            dataGridView1.DefaultCellStyle.Font = new Font("Microsoft JhengHei", 12);
            */
            this.statusTimeLabel.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
            txtName.BackColor = Color.White;
            txtName.ForeColor = Color.Black;         
        }

        private byte[] ReadRegister3(string regID)
        {
            byte[] rdData = new byte[4];
            
            if (serialPort1.IsOpen)
            {
                string scmd = "settestst 1\r";
                serialPort1.WriteLine(scmd);
                //ShowTxLog("rr 0x" + regID + '\r');
                serialPort1.WriteLine("rr 0x" + regID + '\r');
                Thread.Sleep(100);
                string strTmp = serialPort1.ReadExisting();
                //ShowTxLog("REG:"+regID+"=" +strTmp + "\r\n");
                if (!string.IsNullOrEmpty(strTmp))
                    rdData = readRegAnalysis(strTmp);

                scmd = "settestst 0\r";
                serialPort1.WriteLine(scmd);
            }
            //ShowTxLog("Data=" + BitConverter.ToString(rdData) + "\r\n");
            return rdData;
        }

        public int CheckICPowerType()
        {
            int type = 0;
            byte[] revID = new byte[4];
            revID = ReadRegister3(revisionReg);
            //ShowTxLog("[0]" + revID[0] + " [1]" + revID[1] + " [2]" + revID[2] + "- Type[3]: " + revID[3] + "\r\n");
            type = (revID[3] & 0x02) >> 1;
            return type;
        }

        public void InitialTxDatarate()
        {
            int i = 0;
            for (i = 0; i < drList.Length; i++)
            {
                txDRCombo.Items.Add(drList[i]);
            }
            txDRCombo.SelectedIndex = 30;
        }

        public void InitialPowerList()
        {
            int i = 0;
            for (i = 0; i < powerList.Length; i++)
            {
                powerCombo.Items.Add(powerList[i]);
            }
            powerCombo.SelectedIndex = (powerList.Length)-1;
        }
        public void InitialLowPowerList()
        {
            int i = 0;
            for (i = 0; i < LowpowerList.Length; i++)
            {
                powerCombo.Items.Add(LowpowerList[i]);
            }
            powerCombo.SelectedIndex = (LowpowerList.Length) - 1;
        }

        public void InitialRxDatarate()
        {
            int i = 0;
            for (i = 0; i < drList.Length; i++)
            {
                rxDRCombo.Items.Add(drList[i]);
            }
            rxDRCombo.SelectedIndex = 3;
        }
        public void InitialTxMod()
        {
            int i = 0;
            for (i = 0; i < modList.Length; i++)
            {
                txModCombo.Items.Add(modList[i]);
            }
            txModCombo.SelectedIndex = 0;
        }
        public void InitialRxMod()
        {
            int i = 0;
            for (i = 0; i < modList.Length; i++)
            {
                rxModCombo.Items.Add(modList[i]);
            }
            rxModCombo.SelectedIndex = 0;
        }
        public void InitialTxModIdx(int len)
        {
            /*
            int i = 0;
            txModIdxCombo.Items.Clear();
            for (i = 0; i < len; i++)
            {
                txModIdxCombo.Items.Add(modIdxList[i]);
            }
            txModIdxCombo.SelectedIndex = 0;
            */
        }
        public void InitialRxModIdx(int len)
        {
            int i = 0;
            rxModIdxCombo.Items.Clear();
            for (i = 0; i < len; i++)
            {
                rxModIdxCombo.Items.Add(modIdxList[i]);
            }
            rxModIdxCombo.SelectedIndex = 0;
        }
        /*
        public void InitialTxPwr()
        {
            for (int i = 0; i < pwrList.Length; i++)
                pwrCombo.Items.Add(pwrList[i]);
            pwrCombo.SelectedIndex = 0;
        }*/
        //
        // Read Register 用的 Timer
        // 下 Write cmd 後, 開Timer,等收到 Read Reg 值後回傳
        //
        private void ReadRegOnTimer()
        {
            readRegTimer = new System.Timers.Timer(200);
            readRegTimer.Elapsed += new ElapsedEventHandler(OnTimedReadRegProcess);
            //aTimer.AutoReset = true;
            readRegTimer.Enabled = true;
            readRegTimer.Start();
        }
        
        private void SetTimer()
        {
            aTimer = new System.Timers.Timer(2000);
            // Hook up the Elapsed event for the timer. 
            aTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent);  //OnTimedEvent;
            //aTimer.AutoReset = true;
            aTimer.Enabled = true;
            aTimer.Start();
            //iii = 0;
        }
        private void OnTimedReadRegProcess(Object source, ElapsedEventArgs e)
        {
            ReadRegister();
            readRegTimer.Enabled = false;
            readRegTimer.Stop();
            readRegTimer.Dispose();
        }

        public int ckSCPITimes = 0;        
                          

        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            //CheckTxPacketNum();
        }        
       
        public void GetDataRightNow(string str, int mode)
        {
            if (this.InvokeRequired)
            {
                DelGetDataRightNow del = new DelGetDataRightNow(GetDataRightNow);
                this.Invoke(del, str, mode);
            }
            else
            {
                readBackData = str;
                if (mode==0)
                {
                    isWaitingData = false;
                    //DoAutoAdjustFreqAfter(str);
                }
                else if (mode == 1)
                {
                    isGetBackData = false;
                    //WriteBack1580(str, true);
                }
                else if (mode == 2)     // only show IO_Value on TextBox
                {
                    isShowIOData = false;
                    //WriteBack1580(str, false);
                }
                
                //ShowLogOnTxtBox(1, (isWaitingData+"_"+ readBackData), true);
            }
        }

        /// <summary>
        /// Set txSerial
        /// </summary>
        /// <param name="txSerial"></param>
        public void SetController(Controller txSerial)
        {
            this.txSerial = txSerial;
        }

        public void SetController2(Controller2 rxSerial)
        {
            this.rxSerial = rxSerial;
        }

        public void SetController3(Controller3 pcbSerial)
        {
            this.pcbSerial = pcbSerial;

        }

        public void RcvDataToReg()
        {
            int j = 0;
            string stmp = "";
            int startFlag = 64;  // 64=@"

            //txreceivetbx.Text += "rcvIdx=" + rcvIdx + "; end=" + rcvEnd + "\r\n";
            for (int i = 0; i < rcvIdx; i++)
            {
                if (rcvRegArray[i] == startFlag)
                {
                    j = i;
                    break;
                }
            }
            //txreceivetbx.Text += "St=" + j + " \r\n";

            stmp = System.Text.Encoding.UTF8.GetString(rcvRegArray, (j+1), 8);
      
            //if (wrCheckbox.Checked)
            //    txtValue.Text = stmp;
            //else
                
            if (isWaitingData)
            {               
                GetDataRightNow(stmp, 0); // 0 -- for auto freq calibration 
            }
            else if (isGetBackData)
            {
                GetDataRightNow(stmp, 1); // 1 -- for 1580 read back
            }
            else if (isShowIOData)
            {
                GetDataRightNow(stmp, 2); // 1 -- for 1580 show IO value on ioValue.Text
            }
            if (isAutoFreqCal2)
            {
                GetDataRightNow(stmp, 3); // 3 -- for auto freq calibration 2
            }
            if (isTableReadReg)
            {
                isTableReadReg = false;
                regValue[selIdx] = stmp;
                //txreceivetbx.Text += "[" + selIdx + "]= " + regValue[selIdx] + "\r\n ";
                hexTxt.Text = stmp;

                ClearDataGridView();
                try
                {               
                    listView1.Items[selIdx].SubItems[2].Text = stmp; // owen bug
                }
                catch (Exception ex)
                {
                    //insertValue.Text += ex.ToString();
                    //insertValue.Text += "\r\n";
                }
                ShowDataGrid(selIdx);

                try
                {
                    //regValueInt[idx] = int.Parse(stmp, System.Globalization.NumberStyles.HexNumber);
                    stmp = "0x" + stmp;
                    regValueInt[selIdx] = (uint)Convert.ToInt32(stmp, 16);
                }
                catch (InvalidCastException e){
                    // recover from exception
                    txtValue.Text += e.Message + " Transfer tr to int ==> Fail!\r\n";
                }

            }

        }

        //  "@ .....所有register value....... &&"
        //  "64 .............................38 38"
        public void RcvDataToArray()
        {
            int j = 0;
            int idx = 0;
            string stmp = "";
            int startFlag = 64;  // 64=@"

            //txreceivetbx.Text += "rcvIdx=" + rcvIdx + "; end=" + rcvEnd + "\r\n";
            for (int i = 0; i < rcvIdx; i++)
            {
                if (rcvRegArray[i] == startFlag)
                {
                    j = i;
                    break;
                }
            }
            //txreceivetbx.Text += "St=" + j + " ";

            for (int i = (j + 1); i < rcvEnd; i += 8)
            {
                stmp = "";
                stmp = System.Text.Encoding.UTF8.GetString(rcvRegArray, i, 8);
                // * 可以用以下方法每8bytes剪一下, 再每一個bytes轉成str, 也可以只用一條command:
                // * 一次將8bytes轉成 str 
                // * stmp =  System.Text.Encoding.UTF8.GetString(rcvRegArray, i, 8);
                //byte[] bytes = new byte[1];
                //for (int k=i; k<i+8; k++){
                //    bytes[0] = rcvRegArray[k];
                //    stmp += System.Text.Encoding.ASCII.GetString(bytes);                   
                //} 
                regValue[idx] = stmp;
                try
                {
                    //regValueInt[idx] = int.Parse(stmp, System.Globalization.NumberStyles.HexNumber);
                    stmp = "0x" + stmp;
                    regValueInt[idx] = (uint)Convert.ToInt32(stmp, 16);
                }
                catch (InvalidCastException e)
                {
                    // recover from exception
                    txtValue.Text += e.Message + " Transfer tr to int ==> Fail!\r\n";
                }
                //tmpSt = System.Text.Encoding.UTF8.GetString(dataRcv, 2, 3);
                idx++;
            }
        }
        
        public void ShowAllRegisterData()
        {           
            ClearRegisterList();
            TableCreate();    // OWen check
            for (int i = 0; i < regList.Length; i++){
                viewItem = new ListViewItem(regList[i]);
                viewItem.SubItems.Add(regName[i]);
                viewItem.SubItems.Add(regValue[i]);
                listView1.Items.Add(viewItem);
            }
        }

        public void ShowPartialRegisterData()
        {
            ClearRegisterList();
            TableCreate();    // OWen check
            for (int i=0; i<searchRegName.Count; i++)
            {
                viewItem = new ListViewItem(regList[searchRegName[i]]);
                viewItem.SubItems.Add(regName[searchRegName[i]]);
                viewItem.SubItems.Add(regValue[searchRegName[i]]);
                listView1.Items.Add(viewItem);
            }
        }

        // 當第一次收到interrupt時,直接貼在rcvRegArray[0],
        // 之後在 rcvRegArrar 判斷有幾個 "$xxx#&"
        // 找到最後一個#&, Ex: &在[10],然後將[11]後的所有data往前貼在[0]
        // 
        public void rcvRSSIProcess2(byte[] dataR)
        {
            for (int i = 0; i < dataR.Length; i++)
            {
                if (rcvIdx < rcvRegArray.Length)
                {
                    rcvRegArray[rcvIdx] = dataR[i];
                    rcvIdx++;
                }

                if ((dataR[i] == 38) && (dataR[i - 1] == 38))   // @ = 38
                {
                    rcvEnd = (rcvIdx - 2);
                    //RcvDataToArray();
                }
            }
        }

        public void rcvRSSIProcess(byte[] dataR)
        {
            // "$xxx#&"
            try
            {
                for (int i = 0; i < dataR.Length; i++)
                {
                    if ((dataR[i] == '&') && (dataR[i - 1] == '#'))   // @ = 38
                    {
                        rxReceivedNum++;
                        rxrcvtbx.Text = rxReceivedNum.ToString();
                        rxrcvtbx.Update();
                        // * 可以用以下方法每8bytes剪一下, 再每一個bytes轉成str, 也可以只用一條command:
                        string stmp = "";
                        if ((i - 4) >= 0)
                        {
                            stmp = System.Text.Encoding.UTF8.GetString(dataR, (i - 4), 3);
                            nowRssi = (-1) * Convert.ToInt32(stmp);
                            rssiValue.Text = nowRssi.ToString();
                            rssiValue.Update();
                            //ShowRxLog("- " + nowRssi + "\r\n");
                        }
                        else
                            ShowRxLog("Rcv error:len=" + dataR.Length + "\r\n");
                    }
                }
            }
            catch (Exception e)
            {
                ;
            }
            
        }


/*
//        rdr 0x0004
//        [RDR]:0x0004:0x0000011A
//        OK
//        CMD> 

// 0   1    2   3  4  5  6  7  8  9  10 11 12 13 14 15 16 17 18 19 20 21  22 23 24 25 26 27 28  29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50
// --------------------------------------------------------------------------------------------------------------------------------------------------------------
//                                                                                    :  0  x   0  0  0  0  0  1  1  A
// 114 100 114 32 48 120 48 48 48 52 13 13 10 13 91 82 68 82 93 58 48 120 48 48 48 52 58 48 120 48 48 48 48 48 49 49 65 10 13 79 75 10 13 13 10 13 67 77 68 62 32 
            */
        public void ReadAllRegisterProcess(byte[] dataR)
        {
            if (isReadAllRegister){
                for (int i=0; i< dataR.Length; i++){
                    if (rcvIdx < rcvRegArray.Length){
                        rcvRegArray[rcvIdx] = dataR[i];
                        rcvIdx++;
                    }
                    
                    if ((dataR[i] == 38) && (dataR[i - 1] == 38))   // @ = 38
                    {
                        rcvEnd = (rcvIdx - 2);
                        RcvDataToArray();
                        ShowAllRegisterData();
                        isReadAllRegister = false;                        
                    }                       
                }               
            }           
        }

        public void ReadRegisterProcess(byte[] dataR)
        {
            if ((isReadRegister) && ((rcvIdx+ dataR.Length)< rcvRegArray.Length))
            {
                for (int i = 0; i < dataR.Length; i++)
                {
                    rcvRegArray[rcvIdx] = dataR[i];
                    rcvIdx++;                   
                    if ((i > 0) && (dataR[i] == 38) && (dataR[i - 1] == 38))   // @ = 38
                    {
                        rcvEnd = (rcvIdx - 2);
                        RcvDataToReg();
                        //ShowAllRegisterData();
                        //ShowRegisterData();
                        isReadRegister = false;                        
                    }
                }
            }

        }

        /// <summary>
        /// Initialize serial port information
        /// </summary>
        private void InitializeCOMCombox()
        {            
            //Com Ports
            string[] ArrayComPortsNames = SerialPort.GetPortNames();
            if (ArrayComPortsNames.Length == 0)
            {
                //statuslabel.Text = "No COM found !";
                //txopenCloseSpbtn.Enabled = false;
            }
            else
            {
                Array.Sort(ArrayComPortsNames);
                for (int i = 0; i < ArrayComPortsNames.Length; i++)
                {
                    tableCombobox.Items.Add(ArrayComPortsNames[i]);
                }
                tableCombobox.Text = ArrayComPortsNames[0];
                //txopenCloseSpbtn.Enabled = true;
            }
        }

        /// <summary>
        /// update status bar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// Rx COM 接受 data
        public void OpenComEvent(Object sender, SerialPortEventArgs e)
        {
            if (this.InvokeRequired)
            {
                Invoke(new Action<Object, SerialPortEventArgs>(OpenComEvent), sender, e);
                return;
            }

            if (e.isOpend)  //Open successfully
            {
                //statuslabel.Text = txcomListCbx.Text + "- Tx Opened";
                btnRxComConnect.Text = "CLOSE";
                //rxTestStart.Enabled = true;

                autoSendcbx.Enabled = true;
                autoReplyCbx.Enabled = true;
                rxComboBox.Enabled = false;
                //dataBitsCbx.Enabled = false;
                //stopBitsCbx.Enabled = false;
                //parityCbx.Enabled = false;
                btnRxComRefresh.Enabled = false;

               
            }
            else    //Open failed
            {
       
                autoSendcbx.Enabled = false;
                autoReplyCbx.Enabled = false;
            }
        }

        public void OpenComEvent2(Object sender, SerialPortEventArgs2 e)
        {
            if (this.InvokeRequired)
            {
                Invoke(new Action<Object, SerialPortEventArgs2>(OpenComEvent2), sender, e);
                return;
            }

            if (e.isOpend)  //Open successfully
            {

            }
            else    //Open failed
            {
            }
        }

        public void OpenComEvent3(Object sender, SerialPortEventArgs3 e)
        {
            if (this.InvokeRequired)
            {
                Invoke(new Action<Object, SerialPortEventArgs3>(OpenComEvent3), sender, e);
                return;
            }

            if (e.isOpend)  //Open successfully
            {
                //statuslabel.Text = rxcomListCbx.Text + " Opend";
                //pcbopenCloseSpbtn.Text = "Disconnect";
                //pcbsendbtn.Enabled = true;
                autoSendcbx.Enabled = true;
                autoReplyCbx.Enabled = true;

            }
            else    //Open failed
            {

            }
        }

        /// <summary>
        /// update status bar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void CloseComEvent(Object sender, SerialPortEventArgs e)
        {
            if (this.InvokeRequired)
            {
                Invoke(new Action<Object, SerialPortEventArgs>(CloseComEvent), sender, e);
                return;
            }

            if (!e.isOpend) //close successfully
            {
                //statuslabel.Text = txcomListCbx.Text + " Closed";
                btnRxComConnect.Text = "CONNECT";
                autoSendcbx.Enabled = false;
                autoSendtimer.Stop();
                rxComboBox.Enabled = true;
                btnRxComRefresh.Enabled = true;
            }
        }

        public void CloseComEvent2(Object sender, SerialPortEventArgs2 e)
        {
            if (this.InvokeRequired)
            {
                Invoke(new Action<Object, SerialPortEventArgs2>(CloseComEvent2), sender, e);
                return;
            }

            if (!e.isOpend) //close successfully
            {

            }
        }

        public void CloseComEvent3(Object sender, SerialPortEventArgs3 e)
        {
            if (this.InvokeRequired)
            {
                Invoke(new Action<Object, SerialPortEventArgs3>(CloseComEvent3), sender, e);
                return;
            }

            if (!e.isOpend) //close successfully
            {
                //statuslabel.Text = pcbcomListCbx.Text + " Closed";
                //pcbopenCloseSpbtn.Text = "Connect";
                //txPCBPower.Text = "";
                //pcbsendbtn.Enabled = false;
            }
        }

        /// <summary>
        /// Display received data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// Rx COM 接受 data
        public void ComReceiveDataEvent(Object sender, SerialPortEventArgs e)
        {
            if (this.InvokeRequired)
            {
                try
                {
                    Invoke(new Action<Object, SerialPortEventArgs>(ComReceiveDataEvent), sender, e);
                }
                catch (System.Exception)
                {
                    //disable form destroy exception
                }
                return;
            }
            /// Owen: Rx COM 接受 data
            if (recStrRadiobtn.Checked) //display as string // Owen: RX COM RECEIVE
            {
                //ShowRxLog(Encoding.Default.GetString(e.receivedBytes)+" ");
                //rxSenResultText.AppendText(Encoding.Default.GetString(e.receivedBytes));
                if (isRSSIAnalysis)
                    rcvRSSIProcess(e.receivedBytes);
                //if (isReadRegister)
                //    ReadRegisterProcess(e.receivedBytes);
                //if (isReadAllRegister)
                //    ReadAllRegisterProcess(e.receivedBytes);

            }
            else //display as hex
            {
                //if (txreceivetbx.Text.Length > 0){
                //    txreceivetbx.AppendText("-");}
                //txreceivetbx.AppendText(Controller.Bytes2Hex(e.receivedBytes));
            }           
        }
        public void ComReceiveDataEvent2(Object sender, SerialPortEventArgs2 e)
        {
            if (this.InvokeRequired)
            {
                try
                {
                    Invoke(new Action<Object, SerialPortEventArgs2>(ComReceiveDataEvent2), sender, e);
                }
                catch (System.Exception)
                {
                    //disable form destroy exception
                }
                return;
            }           
            
        }

        public void ComReceiveDataEvent3(Object sender, SerialPortEventArgs3 e)
        {
            if (this.InvokeRequired)
            {
                try
                {
                    Invoke(new Action<Object, SerialPortEventArgs3>(ComReceiveDataEvent3), sender, e);
                }
                catch (System.Exception)
                {
                    //disable form destroy exception
                }
                return;
            }

            if (recStrRadiobtn.Checked) //display as string
            {
                //if (meterGetPower == true)
                //   PCBTxPower(e.receivedBytes);
                //pcbreceivetbx.AppendText(Encoding.Default.GetString(e.receivedBytes));

            }
            else //display as hex
            {
                //if (pcbreceivetbx.Text.Length > 0){
                //    pcbreceivetbx.AppendText("-");
                //pcbreceivetbx.AppendText(Controller.Bytes2Hex(e.receivedBytes));
            }
            
        }        

        /// <summary>
        /// update time in status bar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void statustimer_Tick(object sender, EventArgs e)
        {
            this.statusTimeLabel.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
        }


        private void autoSendtimer_Tick(object sender, EventArgs e)
        {
            //txsendbtn_Click(sender, e);
        }

        /// <summary>
        /// filter illegal input of auto send interval time
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void sendIntervalTimetbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == '\b')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Add CRC checkbox changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addCRCcbx_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void SaveInitValue()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            saveFileDialog.Filter = "txt file|*.txt";
            saveFileDialog.DefaultExt = ".txt";
            //saveFileDialog.FileName = "InitialValue.txt";

            //if (saveFileDialog.ShowDialog() == DialogResult.OK){
            //    
            //    System.IO.File.WriteAllText(fName, txreceivetbx.Text);
            //}
            String fName = saveFileDialog.FileName;
            int space = 0;
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {                
                using (StreamWriter sw = new StreamWriter(saveFileDialog.FileName))
                {
                    sw.WriteLine(initTitle);
                    for (int i = 0; i < regName.Length; i++){
                        sw.Write(regList[i]);
                        sw.Write("    ");
                        sw.Write(regName[i]);
                        space = regName[i].Length;
                        for (int j=0; j<(30-space); j++)
                            sw.Write(" ");
                        sw.WriteLine(regValue[i]);
                    }
                }
                //sw.Write("};");
            }
            insertValue.Text += "Save OK\r\n";
        }
     
        public byte[] tRpt = { 58, 67, 65, 76, 67, 58, 77, 65, 82, 75, 49, 58, 89, 63,
                                13, 10, 13,10, 50, 46, 50, 54, 54, 69, 43, 48, 48, 13,
                                10, 83, 67, 80, 73, 62, 32 };
                

        private void MainForm_Load(object sender, EventArgs e)
        {
            btnRandomGenerate.ForeColor = Color.White;
            btnRandomGenerate.BackColor = Color.White;
            try
            {
                LoadIniFile("setting.ini");
            }
            catch (Exception ex)
            {
                ShowInsLog("Load setting.ini failed, Load default setting! \r\n");
            }
        }

        /*  //因為ListView compile 時出er5or, 暫時 closed
        private void SetHeight(ListView listView, int height)
        {
            ImageList imgList = new ImageList();
            imgList.ImageSize = new Size(1, height);
            listView.SmallImageList = imgList;
        }*/
        private void TableCreate()
        {
            listView1.View = View.Details;
            ColumnHeader columnHeader1 = new ColumnHeader();
            columnHeader1.TextAlign = HorizontalAlignment.Left;
            columnHeader1.Text = "Register ID";
            columnHeader1.Width = 150;
            ColumnHeader columnHeader2 = new ColumnHeader();
            columnHeader2.TextAlign = HorizontalAlignment.Left;
            columnHeader2.Text = "Name";
            columnHeader2.Width = 500;
            ColumnHeader columnHeader3 = new ColumnHeader();
            columnHeader3.TextAlign = HorizontalAlignment.Left;
            columnHeader3.Text = "Value (Hex)";
            columnHeader3.Width = 150;
            //ColumnHeader columnHeader4 = new ColumnHeader();
            //columnHeader4.TextAlign = HorizontalAlignment.Center;
            //columnHeader4.Text = "Description";
            //columnHeader4.Width = 300;
            listView1.Columns.Add(columnHeader1);
            listView1.Columns.Add(columnHeader2);
            listView1.Columns.Add(columnHeader3);
            //listView1.Columns.Add(columnHeader4);  
            //SetHeight(listView1, 30);   //因為ListView compile 時出er5or, 暫時 closed
        }
        // Owen OLD method for ReadRegister
        private bool ReadRegister()
        {
            string scmd = "rd1 0x";
            isReadRegister = true;
            bool flag = false;
            rcvIdx = 0;
            rcvEnd = 0;
            for (int i = 0; i < 50; i++){
                rcvRegArray[i] = 0x00;}
            
            try
            {
                scmd = scmd + txtID.Text;
                flag = txSerial.SendDataToCom(scmd + '\r');
                //if (flag)
                //    ShowWriteAllRegLog(("Read [REG]" + txtID.Text + " " + hexTxt.Text + "\r\n"), true);
                //else
                //    ShowWriteAllRegLog(("Read [REG]" + txtID.Text + " FAIL\r\n"), true);
            }
            catch (Exception ex)
            {
                //insertValue.Text += ex.ToString();
                //insertValue.Text += "\r\n";
            }           
            return flag;
        }

        public string readRegReturnStr(string str)
        {
            string stmp = "";
            int endIdx = 0;
            byte[] tmp = Encoding.Default.GetBytes(str);
            int len = tmp.Length;
            if (len > 0)
            {
                for (int i = 8; i < len; i++)
                {
                    if ((tmp[i] == 64) && (tmp[i - 1] == 64))   // @ = 64
                        endIdx = (i - 2);
                }
                //ShowTxLog("len=" + len + "; endIdx=" + endIdx + "\r\n");
                if (endIdx >= 8)
                {
                    int startIdx = (endIdx - 8 + 1);
                    stmp = System.Text.Encoding.UTF8.GetString(tmp, startIdx, 8);
                    
                    //ShowTxLog("Data=" + stmp + "; " + BitConverter.ToString(resu) + "\r\n");
                }
                else
                {
                    ShowTxLog("Read Register Error\r\n");
                }
            }
            return stmp;

        }
        public byte[] readRegAnalysis(string str)
        {
            byte[] resu = new byte[4];
            //char[] charArr = str.ToCharArray();
            //int len = charArr.Length;
            int endIdx = 0;
            byte[] tmp = Encoding.Default.GetBytes(str);
            int len = tmp.Length;
            if (len > 0)
            {
                for (int i = 8; i < len; i++)
                {
                    if ((tmp[i] == 64) && (tmp[i - 1] == 64))   // @ = 64
                        endIdx = (i - 2);
                }
                //ShowTxLog("len=" + len + "; endIdx=" + endIdx + "\r\n");
                if (endIdx >= 8)
                {
                    int startIdx = (endIdx - 8 + 1);
                    string stmp = System.Text.Encoding.UTF8.GetString(tmp, startIdx, 8);
                    uint regValue = (UInt32)Convert.ToInt32(stmp, 16);
                    resu[0] = (byte)(regValue >> 24);
                    resu[1] = (byte)(regValue >> 16);
                    resu[2] = (byte)(regValue >> 8);
                    resu[3] = (byte)regValue;
                    //ShowTxLog("Data=" + stmp + "; " + BitConverter.ToString(resu) + "\r\n");
                }
                else
                {
                    ShowTxLog("Read Register Error\r\n");
                }
            }
            return resu;
        }

        public bool ConnectSerial2()
        {
            bool res = false;
            serialPort1.BaudRate = baudRateNumber;
            serialPort1.PortName = tableCombobox.Text;
            try
            {
                serialPort1.Open();
                ShowTxLog(tableCombobox.Text + " connected\r\n");
                res = true;
            }
            catch (Exception ex)
            {
                //ShowTxLog(ex.ToString() + "\r\n");
                ShowTxLog(tableCombobox.Text + " connect failed\r\n");
            }

            return res;
        }

        public bool ConnectSerial3()
        {
            bool res = false;
            serialPort1.BaudRate = baudRateNumber;
            serialPort1.PortName = txComboBox.Text;
            try
            {
                serialPort1.Open();
                ShowInsLog(txComboBox.Text + " connected\r\n");
                res = true;
            }
            catch (Exception ex)
            {
                //ShowTxLog(ex.ToString() + "\r\n");
                ShowTxLog(txComboBox.Text + " connect failed\r\n");
            }
            return res;
        }

        public bool ConnectSerial4()
        {
            bool res = false;
            serialPort3.BaudRate = baudRateNumber;
            serialPort3.PortName = modeCombobox.Text;
            try
            {
                serialPort3.Open();
                ShowModeLog(modeCombobox.Text + " connected\r\n");
                res = true;
            }
            catch (Exception ex)
            {
                //ShowTxLog(ex.ToString() + "\r\n");
                ShowModeLog(modeCombobox.Text + " connect failed\r\n");
            }
            return res;
        }

        public bool ConnectSerial5()  // for Rx Connect
        {
            bool res = false;
            serialPort2.BaudRate = baudRateNumber;
            serialPort2.PortName = rxComboBox.Text;
            serialPort2.DataReceived += new SerialDataReceivedEventHandler(RxReceiveData);
            try
            {
                serialPort2.Open();
                ShowRxLog(rxComboBox.Text + " connected\r\n");
                res = true;
            }
            catch (Exception ex)
            {
                //ShowTxLog(ex.ToString() + "\r\n");
                ShowRxLog(rxComboBox.Text + " connect failed\r\n");
            }
            return res;
        }

        //private byte[] ReadRegister2(string regID)
        private string ReadRegister2(string regID)
        {
            bool flag = false;
            //byte[] rdData = new byte[4];
            string stmp = "";
            if (!serialPort1.IsOpen)
            {
                flag = ConnectSerial2();
                Thread.Sleep(50);
            }
            if (serialPort1.IsOpen)
            {
                serialPort1.WriteLine("rr 0x" + regID + '\r');
                Thread.Sleep(10);
                string strTmp = serialPort1.ReadExisting();
                //ShowTxLog(strTmp + "\r\n");
                if (!string.IsNullOrEmpty(strTmp))
                    stmp = readRegReturnStr(strTmp);  // rdData = readRegAnalysis(strTmp);
            }
            //ShowTxLog("Data=" + BitConverter.ToString(rdData) + "\r\n");
            return stmp; // rdData;
        }
       

        private bool ReadAllRegister()
        {
            rcvIdx = 0;
            rcvEnd = 0;
            for (int i = 0; i< rcvRegArray.Length; i++){
                rcvRegArray[i] = 0x00;}
            
            isReadAllRegister = true;
            string scmd = "rd2";
            bool flag = txSerial.SendDataToCom(scmd + '\r');

            return flag;
        }

        public bool ReadAllRegister2()
        {
            bool res = false;
            string stmp = "";
            int i = 0;
            int completePercent = 0;
            for (i = 0; i< regList.Length; i++)
            {
                if ((i % 69 == 0) && (i>0) && (i< 340))
                {
                    completePercent = (i * 100)/ regList.Length ;
                    //regRead.Text = completePercent + "%";
                    //regRead.Update();
                    ShowTxLog("..."+ completePercent + "%\r\n");
                }

                stmp = ReadRegister2(regList[i]);
                //ShowTxLog("["+i+"]="+stmp+"\r\n");
                regValue[i] = stmp;
                try
                {
                    //regValueInt[idx] = int.Parse(stmp, System.Globalization.NumberStyles.HexNumber);
                    stmp = "0x" + stmp;
                    regValueInt[i] = (uint)Convert.ToInt32(stmp, 16);
                    res = true;
                }
                catch (InvalidCastException e)
                {
                    // recover from exception
                    insertValue.Text += e.Message + " Transfer tr to int ==> Fail!\r\n";
                }
            }
            ShowAllRegisterData();
            return res;
        }

        //           Read all Register
        private void regRead_Click(object sender, EventArgs e)//Read all Register
        {
            bSearchReg = false;
            searchTxt.Text = "";
            rcvIdx = 0;
            rcvEnd = 0;
            btnTableConnect.Enabled = false;
            btnTableConnect.Update();
            btnWriteAll.Enabled = false;
            btnWriteAll.Update();
            regRead.Enabled = false;
            regRead.Update();

            btnRead1.Enabled = false;
            btnRead1.Update();
            btnRegWrite.Enabled = false;
            btnRegWrite.Update();

            //bool res = ReadAllRegister();     // Owen 原本方式
            DateTime start;
            TimeSpan time;
            start = DateTime.Now;
            ShowTxLog("Reading now ....... \r\n");
            
            bool res = ReadAllRegister2();
            time = DateTime.Now - start;

            btnTableConnect.Enabled = true;
            btnTableConnect.Update();
            btnRead1.Enabled = true;
            btnRead1.Update();
            btnRegWrite.Enabled = true;
            btnRegWrite.Update();
            btnWriteAll.Enabled = true;
            btnWriteAll.Update();
            regRead.Enabled = true;
            regRead.Update();
            if (res == false)
                ShowTxLog("Read Error: Check UART Connection\r\n");
            else
                ShowTxLog("Read All Register Finished!\r\n");// + String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(3, '0')) + "\r\n");
        }

        public static string cutRegID(string t)
        {
            return t.Substring(0, 4);
        }
        public static string cutRegName(string t)
        {
            return t.Substring(8, 25);
        }
        public static string cutRegValue(string t)
        {
            return t.Substring(38, 8);
        }

        private bool LoadRegValue()
        {
            // Data from 30th for each row
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal); //Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            fileDialog.Filter = "txt file|*.txt";
            fileDialog.DefaultExt = ".txt";
            string tmpStr = "";
            int lineCount = 0;
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                lineCount = File.ReadLines(fileDialog.FileName).Count();
                //var lineCount = File.ReadLines(fileDialog.FileName).Count();
                //insertValue.Text += "Read " + fileDialog.FileName + "--> Lines:" + lineCount + "\r\n";
                initialDataPath.Text = fileDialog.FileName;
                //if (!File.ReadLines(fileDialog.FileName).Equals(initTitle))
                //{
                //   insertValue.Text += "Wrong initial data file format!\r\n";
                //}
                //if (lineCount != regValue.Length)
                //    insertValue.Text += "Wrong file format \r\n";
                //else
            }
            else
                return false;

            if (lineCount > 2)
            {
                ShowTxLog("Load: " + fileDialog.FileName + " now......\r\n");
                //string[] readRegValue = new string[lineCount];                                      
                string str = "";
                using (var sr = new StreamReader(fileDialog.FileName))
                {
                    tmpStr = sr.ReadLine();
                    if (!initTitle.Equals(tmpStr))
                    {
                        ShowTxLog("Wrong initial data file format!\r\n");
                        return false;
                    }
                    else
                    {

                        regTableSize = (lineCount - 1);
                        for (int i = 1; i < lineCount; i++)
                        {
                            str = sr.ReadLine();
                            regValue[i - 1] = cutRegValue(str);
                            regName[i - 1] = cutRegName(str);
                            regList[i - 1] = cutRegID(str);
                        }
                        ShowTxLog("Load: " + fileDialog.FileName + " OK......\r\n");
                    }

                }
                return true;
            }
            else
                return false;
                     
        }
        /*
        private void regWrite_Click(object sender, EventArgs e)
        {
            bool flag = false;
            flag = LoadRegValue();
            if (flag)
            {
                bSearchReg = false;
                searchTxt.Text = "";
                ShowAllRegisterData();
            }
            
        } */

        private void DataGridView1_AfterEdit(object sender, EventArgs e)
        {
            //if (setCheckbox.Checked)
            {
                calDataGridValue();
            }
            //insertValue.Text += "Edit OK\r\n";
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int selectedIdx = 0
            //ClearDataGridView();
            
            if ((listView1.SelectedItems.Count > 0))
            {
                try
                {
                    //insertValue.Text = "now=" + listView1.FocusedItem.Index + "\r\n";
                    if (bSearchReg)
                        selIdx = listView1.FocusedItem.Index;
                    txtID.Text = listView1.SelectedItems[0].SubItems[0].Text;
                    txtName.Text = listView1.SelectedItems[0].SubItems[1].Text;
                    txtValue.Text = listView1. SelectedItems[0].SubItems[2].Text;
                }
                catch (Exception ex)
                {
                    insertValue.Text += ex.ToString();
                    insertValue.Text += "\r\n";
                }
            }
            /*
                if ((listView1.SelectedItems != null))// && (!bSearchID))
                {
                    try
                    {
                        selectedIdx = listView1.FocusedItem.Index;
                        selIdx = selectedIdx;               // selIdxIs
                    }
                    catch (Exception ex)
                    {
                        insertValue.Text += ex.ToString();
                        insertValue.Text += "\r\n";
                        selectedIdx = selIdx;
                    }
                }
                //insertValue.Text = "idx=" + selectedIdx;
                ClearDataGridView();
                ShowDataGrid(selIdx);
                //ShowTreeView(selectedIdx);
            }
            */
        }
        private void ClearRegisterList()
        {
            listView1.Clear();
        }
        private void btnSetValue_Click(object sender, EventArgs e)
        {
            string prefixedHex = hexTxt.Text;
            uint intValue =(UInt32) Convert.ToInt32(prefixedHex, 16);
            txtValue.Text += "0x"+prefixedHex +"= " + intValue + "\r\n";
        }

        private void ShowRegister()
        {
            for (int i=0; i<regTableSize; i++)
            {
                //ListViewItem viewItem = new ListViewItem(regList[i]);
                viewItem = new ListViewItem(regList[i]);
                viewItem.SubItems.Add(regName[i]);
                viewItem.SubItems.Add(regValue[i]);
                //viewItem.SubItems.Add(reg);
                listView1.Items.Add(viewItem);
            }

        }

        public void RegisterIDList()
        {
            regIDs = new RegIDs();
            regList = regIDs.RegisterList();
        }

        private void RegisterNameList()
        {
            regNames = new RegNames();
            regName = regNames.RegisterNameList();
            int regSize = regName.Length;
            regTableSize = regSize;       

        }

        public bool FindSelectedIDIdxWhenSearchReg()
        {
            string id = txtID.Text.ToUpper();
            Boolean flag = false;
            for (int i = 0; i < searchRegName.Count; i++)
            {
                if (id.Equals(regList[searchRegName[i]]))
                {
                    selIdx = i;             // selIdxIs
                    
                    flag = true;
                }
            }
            return flag;

        }
        public bool FindSelectedIDIdx()
        {
            string id = txtID.Text.ToUpper();
            Boolean flag = false;
            for (int i = 0; i < regList.Length; i++)
            {
                if (id.Equals(regList[i]))
                {
                    selIdx = i;             // selIdxIs                  
                    flag = true;
                }
            }
            return flag;

        }

        public void Do_SearchRegisterIDIdx()
        {
            bool flag = false;
            if (bSearchReg == false)
                flag = FindSelectedIDIdx();
            else
                flag = FindSelectedIDIdxWhenSearchReg();

            if (flag){
                //bSearchID = true;
                ClearDataGridView();
                listView1.EnsureVisible(selIdx);        // here is selIdx err
                listView1.Select();
                listView1.Items[selIdx].Selected = true;
                if (bSearchReg == false)
                    ShowDataGrid(selIdx);
                else
                    ShowDataGrid(searchRegName[selIdx]);
            }
            else
            {
                //insertValue.Text = "????? \r\n";
                if (bSearchReg == true){
                    bSearchReg = false;
                    ShowAllRegisterData();
                    Do_SearchRegisterIDIdx();
                }                
            }
                
        }
        private void btnClrListview_Click(object sender, EventArgs e)
        {
            //Do_SearchRegisterIDIdx();
            //insertValue.Text += "bSearchID="+bSearchID+"\r\n";
            //insertValue.Text += "bSearchReg=" + bSearchReg + "\r\n";
            string str = txtValue.Text;
            insertValue.Text = str + "-->  ";
            str = clearStrSpace(str);
            insertValue.Text += str + "\r\n";
        }

        private bool WriteReg2(string reg, string sData)
        {
            string cmd = "wr 0x" + reg + " 0x" + sData+"\r";
            bool flag = false;
            flag = serialPort1.IsOpen;
            if (flag)
                serialPort1.WriteLine(cmd);

            return flag;

        }
        private void WriteReg(string reg, string sData, bool bRead)
        {
            string cmd = "wrr 0x" + reg + " 0x" + sData;
            bool flag = txSerial.SendDataToCom(cmd + '\r');
            //if (flag == false)
            //    insertValue.Text += "WR: Error \r\n";
            //else
            if ((flag)&& (bRead))
            {
                insertValue.Text += ": OK \r\n";            
            }
        }

        public void ReadOneRegister()
        {
            string reg = txtID.Text;
            string sdata = txtValue.Text;
            string stmp = "";
            bool flag = WriteReg2(reg, sdata);
            if (flag)
            {
                ShowTxLog("write [REG]" + reg + " 0x" + sdata + "\r\n");
                Thread.Sleep(100);
                stmp = ReadRegister2(reg);
                AfterReadProcess(stmp);
            }
            else
            {
                ShowTxLog("write [REG]" + reg + " 0x" + sdata + " FAILED \r\n");
            }
        }

        private void btnRegWrite_Click(object sender, EventArgs e)
        {
            ReadOneRegister();
            /*
            string reg = txtID.Text;
            string sdata = txtValue.Text;
            string stmp = "";
            ShowTxLog("write [REG]" + reg + " 0x" + sdata+"\r\n");
            isTableReadReg = true;
            WriteReg(reg, sdata, true);   // Owen 原本方式
            */
        }       
      
        public uint CalMaskValue(int val)
        {
            uint res = 0;
            res = (uint) Math.Pow(2, val);
            return (res-1);
        }
        public void ShowDataGrid(int idx)
        {
            //string hexData = "3FCD02A0";
            uint intValue = (UInt32)Convert.ToInt32(regValue[idx], 16);
            //insertValue.Text = intValue.ToString() + "\r\n";
            int len = regCont[idx].Length;
            uint[] FS_Data = new uint[len];
            /*
            //if (idx == 39)
            {
                int[] FS_MASK = { 0x1, 0x2, 0x1c, 0xe0, 0x700, 0x800, 0x1000, 0x7e000, 0xff80000, 0x10000000, 0x20000000 };
                int[] FS_POS = { 0, 1, 2, 5, 8, 11, 12, 13, 19, 28, 29 };
                int[] FS_MASK2 = { 0x1, 0x1, 0x7, 0x7, 0x7, 0x1, 0x1, 0x3F, 0x1FF, 0x1, 0x1 };
                for (int i = 0; i < FS_MASK.Length; i++)
                {
                    FS_Data[i] = (int)(intValue & FS_MASK[i]) >> FS_POS[i];
                    //FS_Data[i] = (int)(intValue  >> FS_POS[i]) & FS_MASK2[i];
                    //insertValue.Text += regCont[idx][i] + "= " + FS_Data[i] + "\r\n";
                }
            }*/
            for (int i = 0; i < fsMaskMatrix[idx].Length; i++)
            {
                if (fsMaskMatrix[idx][i] == 32)
                    FS_Data[i] = (uint) intValue;
                else
                    FS_Data[i] = (uint)(intValue  >> fsPosMatrix[idx][i]) & CalMaskValue(fsMaskMatrix[idx][i]);
                //insertValue.Text += regCont[idx][i] + "= " + FS_Data[i] + "\r\n";
            }
            for (int i = 0; i < len; i++)
            {
                DataGridViewRow row = (DataGridViewRow)dataGridView1.Rows[i].Clone();
                row.Cells[0].Value = regCont[idx][i];
                row.Cells[1].Value = bitRangeMatrix[idx][i];
                //row.Cells[2].Value = CalMaskValue(fsMaskMatrix[idx][i]);
                row.Cells[2].Value = "0x"+FS_Data[i].ToString("X");
                dataGridView1.Rows.Add(row);
                if (row.Cells[0].Value.Equals("RESERVED")) { 
                    //dataGridView1.Rows[i].ReadOnly = true;
                    dataGridView1.Rows[i].Visible = false;
                    //dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.DimGray;
                }
                dataGridView1.Columns[0].ReadOnly = true;
                dataGridView1.Columns[1].ReadOnly = true;
                
            }
            dataGridView1.Rows[len].DefaultCellStyle.BackColor = Color.DimGray;
            dataGridView1.Rows[len].ReadOnly = true;
        }

        private void ClearDataGridView()
        {
            dataGridView1.Rows.Clear();
        }

        public void AfterReadProcess(string stmp)
        {
            //isTableReadReg = false;
            regValue[selIdx] = stmp;
            //txreceivetbx.Text += "[" + selIdx + "]= " + regValue[selIdx] + "\r\n ";
            hexTxt.Text = stmp;

            ClearDataGridView();
            try
            {
                listView1.Items[selIdx].SubItems[2].Text = stmp; // owen bug
                stmp = "0x" + stmp;
                regValueInt[selIdx] = (uint)Convert.ToInt32(stmp, 16);
            }
            catch (Exception ex) { insertValue.Text += ex.ToString() + "\r\n"; }
                
            ShowDataGrid(selIdx);
            /*
            try
            {
                //regValueInt[idx] = int.Parse(stmp, System.Globalization.NumberStyles.HexNumber);
                stmp = "0x" + stmp;
                regValueInt[selIdx] = (uint)Convert.ToInt32(stmp, 16);
            }
            catch (InvalidCastException ex)
            {
                // recover from exception
                insertValue.Text += ex.Message + "-> Transfer tr to int ==> Fail!\r\n";
            }
            */
        }
        //           btnRead1
        private void btnTree_Click(object sender, EventArgs e)  // Owen Read 1 Reg
        {
            //isTableReadReg = true;
            string stmp = "";
            bool flag = false;
            if (bSearchReg == false)
                flag = FindSelectedIDIdx();
            else
                flag = FindSelectedIDIdxWhenSearchReg();
            //if (flag)
            //    ReadRegister();  //Owen: 原本方法
            if (flag)
                stmp = ReadRegister2(txtID.Text);

            //if (isTableReadReg)
            AfterReadProcess(stmp);
            
        }

        private bool ckStrIsHex(string str)
        {
            bool res = false;
            string spaceInput = " ";
            if (str.Contains(spaceInput))
                return res;
            else
            {
                ;
            }
            return res;
        }

        private string clearStrSpace(string str)
        {
            string spaceInput = " ";
            string str2 = str;
            if (str.Contains(spaceInput))
            {
                //insertValue.Text += "HAS SPACE ==> ";
                str2 = str.Replace(spaceInput, "");
            }                         
            return str2;
        }
        private void calDataGridValue()
        {
            uint regData = 0;
            int len = (dataGridView1.Rows.Count) - 1; // 因為尾部有addrow(), 所以要-1
            //insertValue.Text = "Row count=" + len +"\r\n";
            uint[] rowData = new uint[len];
            string str = "";
            uint maxRange = 0;
            const string PATTERN = @"[A-Fa-f0-9]+$";
            /*
            int[] FS_MASK   = { 0x1, 0x2, 0x1c, 0xe0, 0x700, 0x800, 0x1000, 0x7e000, 0xff80000, 0x10000000, 0x20000000 };           
            int[] FS_POS    = {    0,  1,  2,      5,      8,      11,   12,      13,     19,       28,          29 };
            //int[] FS_MASK2  = { 0x1, 0x1, 0x7,  0x7,  0x7,   0x1,   0x1,    0x3F,    0x1FF,     0x1,        0x1 };
            for (int i=0; i<(len-1); i++)
            {
                str = dataGridView1.Rows[i].Cells[1].Value as string;
                rowData[i] = (UInt32)Convert.ToInt32(str, 16);
                //insertValue.Text += regCont[39][i]+"=" + rowData[i] + "\r\n";                
                //regData = regData | (UInt32)((rowData[i] & FS_MASK2[i]) << FS_POS[i]);
                regData = regData | (UInt32)((rowData[i] & (FS_MASK[i] >> FS_POS[i])) << FS_POS[i]);
            }
            */
            
            for (int i = 0; i < len; i++)    //fsPosMatrix[selIdx].Length
            {
                try
                {
                    str = dataGridView1.Rows[i].Cells[2].Value as string;
                    str = clearStrSpace(str);
                    dataGridView1.Rows[i].Cells[2].Value = str;
                    if (str.Equals("")){
                        // Owen: over range
                        break;
                    }
                    else if ((str.Length > 2) && (str.Substring(0, 2).ToLower() == "0x"))
                    {
                        str = str.Substring(2, (str.Length - 2));
                        if (str.Equals("")){
                            insertValue.Text += "Wrong input " + str + "\r\n";
                            break;
                        }
                        else if (System.Text.RegularExpressions.Regex.IsMatch(str, PATTERN))
                            rowData[i] = (uint)Convert.ToInt32(str, 16);
                        else
                        {
                            insertValue.Text += "Wrong input " + str + "\r\n";
                            break;
                        }
                    }
                    else {
                        if (str.All(char.IsDigit))
                            rowData[i] = (uint)Int32.Parse(str);
                        else
                        {
                            insertValue.Text += "Wrong input "+str+"\r\n";
                            break;
                        }
                            
                    }
                        if (dataGridView1.Rows[i].Cells[0].Value.Equals("RESERVED") == false)
                        {
                            if (bSearchReg == false)
                                maxRange = CalMaskValue(fsMaskMatrix[selIdx][i]);
                            else
                                maxRange = CalMaskValue(fsMaskMatrix[searchRegName[selIdx]][i]);
                  
                            if (rowData[i] > maxRange)
                            {
                                if (MessageBox.Show(("Max Value of " + dataGridView1.Rows[i].Cells[0].Value + " = " + maxRange + "\r\n Do you want to change it?"), "ERROR", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                                {
                                    dataGridView1.Rows[i].Cells[2].Value = "0x"+maxRange.ToString("X");
                                }                                
                            }
                        }
                        if (bSearchReg == false)
                            regData = regData | (uint)((rowData[i] & maxRange) << fsPosMatrix[selIdx][i]);
                        else
                            regData = regData | (uint)((rowData[i] & maxRange) << fsPosMatrix[searchRegName[selIdx]][i]);
                       

                }
                catch (Exception ex){
                    insertValue.Text += "Please input number\r\n";
                    //insertValue.Text += "ex: sel="+selIdx+"\r\n";
                    //insertValue.Text += ex.ToString();
                    //insertValue.Text += "\r\n";
                }
            }
            //insertValue.Text += "Final = " + regData+ "=  0x"+ regData.ToString("X")+"\r\n";
            txtValue.Text = regData.ToString("X8");
        }
        private void valueSet_Click(object sender, EventArgs e)
        {
            calDataGridValue();      
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
            if (txtID.Text.Length == 4)
            {
                //bSearchID = true;
                Do_SearchRegisterIDIdx();
            }
        }
        private void FullInSearchRegName()
        {
            for (int i=0; i< regList.Length; i++)
            {
                searchRegName.Add(i);
            }
        }

        private void Do_SearchRegisterName()
        {
            string str = searchTxt.Text;
            searchRegName.Clear();
            //int num = 0;
            bool res = false;
            for (int i=0; i<regName.Length; i++){
                res = regName[i].Contains(str);
                if (res)
                {
                    //insertValue.Text += "[" + i + "]-[" + regList[i] + "] = {" + regName[i] + "}\r\n";
                    searchRegName.Add(i);
                    //num++;
                }                   
            }
            ShowPartialRegisterData();
        }

        private void searchTxt_TextChanged(object sender, EventArgs e)
        {
            
            //ClearDataGridView();
            if ((searchTxt.Text.Length >= 2) && (searchTxt.Text.Length <= 26)){
                string str = searchTxt.Text;
                string spaceInput = " ";
                bool res = false;
                res = str.Contains(spaceInput);
                if (res)
                    insertValue.Text += "String can not has 'Space'\r\n";
                else
                {
                    bSearchReg = true;
                    txtID.Enabled = false;
                    insertValue.Text = "";
                    Do_SearchRegisterName();
                }
                
            }
            else if(searchTxt.Text.Length == 0)
            {
                bSearchReg = false;
                FullInSearchRegName();
                insertValue.Text = "";
                ShowAllRegisterData();
                txtID.Enabled = true;
            }
        }

        private bool writeProc(string regid, string wrValue)
        {
            bool res = false;
            string cmd = "wra 0x" + regid + " 0x" + wrValue;
            //insertValue.Text += "write [REG]" + regid + " 0x" + wrValue;
            res = txSerial.SendDataToCom(cmd + '\r');
            return res;
        }       

        public void WriteAllRegProc2()
        {
            DateTime start;  
            TimeSpan time;
            
            ShowTxLog("Write All Register Start -----\r\n");
            int i = 0;
            int completePercent = 0;
            string cmd = "";
            if (serialPort1.IsOpen)
            {
                start = DateTime.Now;
                btnWriteAll.Enabled = false;
                btnWriteAll.Update();
                for (i = 0; i < regList.Length; i++)
                {
                    if ((i % 69 == 0) && (i > 0) && (i < 340))
                    {
                        completePercent = (i * 100)/ regList.Length ;
                        //regRead.Text = completePercent + "%";
                        //regRead.Update();
                        ShowTxLog("..." + completePercent + "%\r\n");
                    }
                    cmd = "wr 0x" + regList[i] + " 0x" + regValue[i] + "\r";
                    serialPort1.WriteLine(cmd);
                    Thread.Sleep(15);
                }
                time = DateTime.Now - start;
                btnWriteAll.Enabled = true;
                btnWriteAll.Update();
                ShowTxLog("Write All Register Finished! \r\n"); //+ String.Format("{0}.{1}", time.Seconds, time.Milliseconds.ToString().PadLeft(3, '0')) + "\r\n");
            }
            else
                ShowTxLog("COM PORT ERROR\r\n");
        }
        private void btnWriteAll_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(("Do you really want to write all register now?"), "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                btnTableConnect.Enabled = false;
                btnTableConnect.Update();
                regRead.Enabled = false;
                regRead.Update();
                btnRead1.Enabled = false;
                btnRead1.Update();
                btnRegWrite.Enabled = false;
                btnRegWrite.Update();

                WriteAllRegProc2();

                regRead.Enabled = true;
                regRead.Update();
                btnTableConnect.Enabled = true;
                btnTableConnect.Update();
                btnRead1.Enabled = true;
                btnRead1.Update();
                btnRegWrite.Enabled = true;
                btnRegWrite.Update();
            }
        }
        private void loadInitFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool flag = false;
            flag = LoadRegValue();
            if (flag)
            {
                bSearchReg = false;
                searchTxt.Text = "";
                ShowAllRegisterData();
            }
            else
            {
                ShowTxLog("Load file error!\r\n");
            }           
        }        
        private bool ReadReg(string reg)
        {
            rcvIdx = 0;
            rcvEnd = 0;
            for (int i = 0; i < 50; i++){
                rcvRegArray[i] = 0x00;
            }
            readBackData = "";
            isReadRegister = true;
            string scmd = "rd1 0x" + reg;
            
            bool flag = txSerial.SendDataToCom(scmd + '\r');

            return flag;
        }
        private void TryRead()
        {
            isWaitingData = true;
            bool flag = ReadReg("1580");
            int i = 0;
            while (isWaitingData==false)
            {
                Thread.Sleep(5);
                //ShowLogOnTxtBox(1, (i+": "+readBackData + ": " + isWaitingData), true);
                i++;
            }           
        }

        private void GetBackDataAndWrite(string regStr, bool bWrite)
        {
            if (bWrite)
                isGetBackData = true;
            else
                isShowIOData = true;
            bool flag = ReadReg(regStr);           
        }
                                                        
        public void ShowTxLog(string str)
        {
            insertValue.Text = insertValue.Text.Insert(0, str);
            insertValue.Update();
        }

        public void ShowInsLog(string str)
        {
            //txResult.Text = txResult.Text.Insert(0, str);
            txResult.Text += str;
            txResult.Update();
            txResult.SelectionStart = txResult.Text.Length;
            txResult.ScrollToCaret();
        }
        public void ShowRxLog(string str)
        {
            //rxResult.Text = rxResult.Text.Insert(0, str);
            if (this.InvokeRequired)
            {
                DelShowRxLog del = new DelShowRxLog(ShowRxLog);
                this.Invoke(del, str);
            }
            else
            {
                //txPCBPower.Text = str;
                rxResult.Text = str;
                rxResult.Update();
            }           
        }
        public void ShowModeLog(string str)
        {
            //modeTextbox.Text = modeTextbox.Text.Insert(0, str);
            modeTextbox.Text = str;
            modeTextbox.Update();
        }
        private void btnTxClear_Click(object sender, EventArgs e)
        {
            txResult.Clear();
        }       
        /*  //Owen: 原本是 tx num len send 的, 暫時Hold 住
        private void btnFIFOSend_Click(object sender, EventArgs e)
        {
            int txnum = Convert.ToInt32(fifoNum.Text);
            //int timeDelay = Convert.ToInt32(txfifoIntv.Text);
            btnFIFOSend.Enabled = false;
            btnFIFOSend.Update();

            if (serialPort1.IsOpen)
            {
                ShowInsLog("Send Packet...\r\n");
                serialPort1.WriteLine("tx "+ txnum + " 30 10\r");   // tx num pklen=30 intv=30 \r
            }
            else
            {
                btnFIFOSend.Enabled = true;
                btnFIFOSend.Update();
                ShowInsLog("COM PORT ERROR\r\n");
            }
            
            btnFIFOSend.Enabled = true;
            btnFIFOSend.Update();
        }
        */
        private void btnCW_Click(object sender, EventArgs e)
        {
            if (btnCW.Text.Equals("CW ON"))
            {
                btnCW.Text = "CW OFF";
                btnCW.BackColor = Color.Red;
                if (serialPort1.IsOpen)
                    serialPort1.WriteLine("txst 1 23\r");
                else
                    ShowInsLog("COM PORT ERROR\r\n");
            }
            else
            {
                btnCW.Text = "CW ON";
                btnCW.BackColor = Color.LightGray;
                if (serialPort1.IsOpen)
                    serialPort1.WriteLine("txst 0 23\r");
                else
                    ShowInsLog("COM PORT ERROR\r\n");
            }
        }

        public bool ER4100_SetParameter()
        {
            bool res = false;
            string stmp = "";
            int pwIdx = powerCombo.SelectedIndex;
            int drIdx = txDRCombo.SelectedIndex;
            //txResult.Text += "Idx=" + idx + "   ";
            //txResult.Text += "PowerLevel=" + powerLevelList[idx] + "\r\n";
            
            if (!serialPort1.IsOpen)
            {
                ShowInsLog("COMPORT FAIL\r\n");
                return res;
            }                
            else
            {                
                int freqValue = 0;
                int drValue = 0;
                int moduValue = 4;
                int mod_idx_Value = 8;
                double freqDevDouble = Convert.ToDouble(freqDev.Text);
                double freqDouble = Convert.ToDouble(txFreqText.Text);
                int freqDevValue = 0;
                string syncwordInput = txSyncword.Text;
                string syncwordString = hexReverse(syncwordInput);
                string cmd = "";
                freqValue = (int) (1000000*freqDouble);
                drValue = Convert.ToInt32(drList2[drIdx]);               
                freqDevValue = (int) (2 * 1000 * freqDevDouble);
                serialPort1.WriteLine("rx 0\r");
                Thread.Sleep(50);

                if (highlowICType == 0)
                {
                    serialPort1.WriteLine("cfg 11 14\r");
                    Thread.Sleep(100);
                    cmd = "cfg 6 " + LowpowerLevelList[pwIdx] + " " + freqValue + " " + drValue + " " + moduValue + " " + mod_idx_Value + "\r";
                }
                else
                {
                    serialPort1.WriteLine("cfg 11 23\r");
                    Thread.Sleep(100);
                    cmd = "cfg 6 " + powerLevelList[pwIdx] + " " + freqValue + " " + drValue + " " + moduValue + " " + mod_idx_Value + "\r";
                }
                serialPort1.WriteLine(cmd);
                Thread.Sleep(250);
                stmp = serialPort1.ReadExisting();
                //ShowInsLog(stmp + "\r\n");
                cmd = ("cfg 7 0x" + syncwordString +"\r");
                serialPort1.WriteLine(cmd);
                Thread.Sleep(50);
                stmp = serialPort1.ReadExisting();
                //ShowInsLog(stmp + "\r\n");
                cmd = "cfg 18 2\r";
                serialPort1.WriteLine(cmd);
                Thread.Sleep(50);
                cmd = "cfg 15 " + freqDevValue + "\r";
                serialPort1.WriteLine(cmd);
                Thread.Sleep(100);
                //ShowInsLog("SET TX OK\r\n");
                stmp = serialPort1.ReadExisting();
                //ShowInsLog(stmp+"\r\n");
                stmp = ("Set Parameter: "+txFreqText.Text+"MHz, "+txDRCombo.Text+"kbps, "+ freqDev.Text+"kbps, "+ powerCombo.Text+ "dBm OK\r\n");
                ShowInsLog(stmp);
                res = true;
            } 
            return res;
        }

        public int highlowICType = 0;
        // Set Tx Parameter
        private void btnSetER4100_Click(object sender, EventArgs e)
        {
            bool res = false;
            if (!serialPort1.IsOpen)
            {
                ShowInsLog("COMPORT FAIL\r\n");
            }
            else
            {               
                res = ER4100_SetParameter(); // Set Tx Parameter
            }
            
        }

        System.Threading.Thread CloseDown2;
        private void rxopenCloseSpbtn_Click(object sender, EventArgs e)
        {
             // 這是原本的 thread 方法
            if (isRxOldMethod)
            {
                if (btnRxComConnect.Text == "CONNECT")
                {
                    txSerial.OpenSerialPort(        // rx com
                        rxComboBox.Text,
                        baudRateNumber.ToString(),
                        "8", //dataBitsCbx.Text, 
                        "One", //stopBitsCbx.Text, 
                        "None", //parityCbx.Text,
                        "None" //handshakingcbx.Text
                        );
                    btnRxStart.Text = "RX START";
                }
                else
                {
                    btnRxComConnect.Text = "CONNECT";
                    btnRxComRefresh.Enabled = true;
                    rxComboBox.Enabled = true;
                    txSerial.CloseSerialPort();
                }
            }
            else
            {
                // 法2, c# serialport 元件
                if (btnRxComConnect.Text == "CONNECT")
                {
                    if (!serialPort2.IsOpen)
                    {
                        ConnectSerial5();
                    }
                    Thread.Sleep(100);

                    if (serialPort2.IsOpen)
                    {
                        btnRxComConnect.Text = "CLOSE";
                        btnRxComRefresh.Enabled = false;
                        rxComboBox.Enabled = false;
                        Thread.Sleep(20);
                        //serialPort2.WriteLine("settestst 1\r");
                    }
                }
                else
                {
                    if (serialPort2.IsOpen)
                    {
                        //serialPort2.Close();  // 原本簡單的方法
                        CloseDown2 = new System.Threading.Thread(new System.Threading.ThreadStart(CloseSerial2OnExit));
                        CloseDown2.Start();
                    }
                    btnRxComConnect.Text = "CONNECT";
                    btnRxComRefresh.Enabled = true;
                    rxComboBox.Enabled = true;
                }
            }                        
        }
        private void CloseSerial2OnExit()
        {
            try
            {
                serialPort2.DataReceived -= RxReceiveData;
                serialPort2.DiscardInBuffer();
                serialPort2.DiscardOutBuffer();
                serialPort2.Close();
            }
            catch (Exception ex)
            {
                ShowRxLog(ex.Message + "\r\n");
            }
        }

        // Owen: SG 操作
        // Preset --> mode --> Dual ARB --> Select Waveform --> explorer --> int_storage
        // ER4_2000K_0P5.WFM --> Load Segment from INt_Media --> return
        // Select waveform
        // trig --> Single --> buffered trigger
        // Trig source --> Trig souurce (Ext) --> Trigger key
        // Dual ARB --> ON
        // RF ON

        public bool ER4100_RxSetParameter()
        {
            bool res = false;
            if (isRxOldMethod)  // 用Thread
                res = ER4100_SendCmdThread("\r");
            else
                res = ER4100_RxSendCmd("\r");
            if (!res)
                return res;
            else
            {
                int freqValue = 0;
                int drValue = 0;
                int moduValue = 4;
                int mod_idx_Value = 8;
                int pwr = 127;
                freqValue = Convert.ToInt32(rxFreqText.Text);
                drValue = Convert.ToInt32(rxDRCombo.Text);
                switch (rxModCombo.SelectedIndex)
                {
                    case 0: moduValue = 4; break;
                    default: moduValue = 4; break;
                }
                switch (rxModIdxCombo.SelectedIndex)
                {
                    case 0:
                        mod_idx_Value = 8;
                        break;
                    case 1:
                        mod_idx_Value = 16;
                        break;
                    case 2:
                        mod_idx_Value = 32;
                        break;
                    case 3:
                        mod_idx_Value = 64;
                        break;

                }

                if (isRxOldMethod)
                {
                    ER4100_SendCmdThread("rx 0\r");
                    Thread.Sleep(100);
                    ER4100_SendCmdThread("cfg 6 " + pwr + " " + freqValue + " " + drValue + " " + moduValue + " " + mod_idx_Value + "\r");
                    Thread.Sleep(100);
                    ER4100_SendCmdThread("rx 1 0 128 0\r"); // RX ON
                }
                else
                {
                    ER4100_RxSendCmd("rx 0\r");
                    Thread.Sleep(100);
                    ER4100_RxSendCmd("cfg 6 " + pwr + " " + freqValue + " " + drValue + " " + moduValue + " " + mod_idx_Value + "\r");
                    Thread.Sleep(100);
                    ER4100_RxSendCmd("rx 1 0 128 0\r"); // RX ON
                }
                /*
                Para[1] for Enable or Disable
                Para[2] 0 for 802.15.4
                        1 for transparent
                Para[3] for max fifo length
                Para[4] for 1 to stop Auto recovery Rx
                */
                res = true;
            }
            return res;
        }

        public bool ER4100_SendCmdThread(string cmd)
        {
            bool res = false;
            res = txSerial.SendDataToCom(cmd);
            return res;
        }

        public bool ER4100_RxSendCmd(string cmd)
        {
            bool res = false;
            res = serialPort2.IsOpen;
            if (res)
            {
                serialPort2.WriteLine(cmd);
                res = true;
            }
            return res;
        }

        public bool ER4100_SendCmd(string cmd)
        {
            bool res = false;
            res = serialPort1.IsOpen;
            if (res)
            {
                serialPort1.WriteLine(cmd);
                res = true;
            }            
            return res;
        }

        public bool ER4100_SendModeCmd(string cmd)
        {
            bool res = false;
            res = serialPort3.IsOpen;
            if (res)
            {
                serialPort3.WriteLine(cmd);
                res = true;
            }
            return res;
        }

        public bool SetRxTestMode(int rOn)
        {
            bool res = false;
            if (isRxOldMethod)
                res = ER4100_SendCmdThread("settestst "+rOn+"\r");
            else
                res = ER4100_RxSendCmd("settestst " + rOn + "\r");
            return res;
        }

        public bool SetRxPerMode(int rOn)
        {
            bool res = false;
            if (isRxOldMethod) 
                res = ER4100_SendCmdThread("setperst " + rOn + "\r");
            else
                res = ER4100_RxSendCmd("setperst " + rOn + "\r");
            return res;
        }

        public bool ClrRxResult()
        {
            bool res = false;
            if (isRxOldMethod) 
                res = ER4100_SendCmdThread("perclr\r");
            else
                res = ER4100_RxSendCmd("perclr\r");
            return res;
        }        

        private void btnRxResultClr_Click(object sender, EventArgs e)
        {
            ClrRxResult();
        }
        
        public bool GetRxResult()
        {
            bool res = false;
            res = ER4100_SendCmd("pernum\r");
            string str = "";
            if (res)
            {
                Thread.Sleep(100);
                str = serialPort1.ReadExisting();
                ShowRxLog(str+"\r\n");
            }
            return res;
        }

        private void btnRxGetResult_Click(object sender, EventArgs e)
        {
            GetRxResult();
        }

        private void btnRxStart_Click(object sender, EventArgs e)
        {
            bool res = false;
            if (btnRxStart.Text == "RX START")
            {
                if (isRxOldMethod)
                    res = ER4100_SendCmdThread("\r");
                else
                    res = ER4100_RxSendCmd("\r");
                if (!res)
                {
                    ShowRxLog("COM PORT ERRPR\r\n");
                }   
                else
                {
                    isRxSenStart = true;
                    lastRSSI = "";
                    res = SetRxTestMode(1);
                    Thread.Sleep(100);
                    res = SetRxPerMode(1);
                    rxTestMode = true;
                    btnRxStart.Text = "RX STOP";
                    btnRxStart.Update();
                    rxReceivedNum = 0;
                    nowRssi = 0;
                    //avgRssi = 0;
                    //rcvIdx = 0;
                    //rcvEnd = 0;
                    rxrcvtbx.Text = rxReceivedNum.ToString();
                    rssiValue.Text = nowRssi.ToString();
                    //avgrssitbx.Text = avgRssi.ToString();
                    isRSSIAnalysis = true;
                    serialPort2.DiscardOutBuffer();
                    serialPort2.DiscardInBuffer();

                    ShowRxLog("Set Rx Mode: ON\r\n");
                }               
            }
            else
            {
                
                res = SetRxTestMode(0);
                Thread.Sleep(100);
                res = SetRxPerMode(0);
                if (res)
                {
                    serialPort2.DiscardOutBuffer();
                    serialPort2.DiscardInBuffer();
                    rxTestMode = false;
                    isRSSIAnalysis = false;
                    lastRSSI = "";
                    isRxSenStart = false;
                    btnRxStart.Text = "RX START";
                    btnRxStart.Update();
                    ShowRxLog("Set Rx Mode: OFF\r\n");
                }
                else
                    ShowRxLog("COM PORT ERRPR\r\n");
            }                        
                          
        }

        private void btnRxGetResult_Click_1(object sender, EventArgs e)
        {

        }

        private void btnRxResultClr_Click_1(object sender, EventArgs e)
        {
            rxReceivedNum = 0;
            nowRssi = 0;
            rxrcvtbx.Text = rxReceivedNum.ToString();
            rxrcvtbx.Update();
            rssiValue.Text = nowRssi.ToString();
            rssiValue.Update();
        }

        private void btnRxSet_Click_1(object sender, EventArgs e)
        {            
            bool res = ER4100_RxSetParameter();
            if (res)
            {
                ShowRxLog("RX SET OK\r\n");
                rxReceivedNum = 0;
                ShowRxRcvNum(rxReceivedNum.ToString(), "");
            }
                
            else
                ShowRxLog("RX SET FAIL\r\n");
        }

        public void TxComRefresh()
        {
            txComboBox.Items.Clear();
            string[] ArrayComPortsNames = SerialPort.GetPortNames();
            if (ArrayComPortsNames.Length == 0)
            {
                btnTxComConnect.Enabled = false;
            }
            else
            {
                Array.Sort(ArrayComPortsNames);
                for (int i = 0; i < ArrayComPortsNames.Length; i++)
                {
                    txComboBox.Items.Add(ArrayComPortsNames[i]);
                }
                txComboBox.Text = ArrayComPortsNames[0];
                btnTxComConnect.Enabled = true;
                //statuslabel.Text = "OK !";
            }
        }
        public void RxComRefresh()
        {
            rxComboBox.Items.Clear();
            string[] ArrayComPortsNames = SerialPort.GetPortNames();
            if (ArrayComPortsNames.Length == 0)
            {
                //statuslabel.Text = "No COM found !";
                btnRxComConnect.Enabled = false;
            }
            else
            {
                Array.Sort(ArrayComPortsNames);
                for (int i = 0; i < ArrayComPortsNames.Length; i++)
                {
                    rxComboBox.Items.Add(ArrayComPortsNames[i]);
                }
                rxComboBox.Text = ArrayComPortsNames[0];
                btnRxComConnect.Enabled = true;
                //statuslabel.Text = "OK !";
            }
        }
        public void ModeComRefresh()
        {
            modeCombobox.Items.Clear();
            string[] ArrayComPortsNames = SerialPort.GetPortNames();
            if (ArrayComPortsNames.Length == 0)
            {
                btnModeComConnect.Enabled = false;
            }
            else
            {
                Array.Sort(ArrayComPortsNames);
                for (int i = 0; i < ArrayComPortsNames.Length; i++)
                {
                    modeCombobox.Items.Add(ArrayComPortsNames[i]);
                }
                modeCombobox.Text = ArrayComPortsNames[0];
                btnModeComConnect.Enabled = true;
                //statuslabel.Text = "OK !";
            }
        }
        private void btnRxComRefresh_Click(object sender, EventArgs e)
        {
            RxComRefresh();
        }

        private void btnTxComRefresh_Click(object sender, EventArgs e)
        {
            TxComRefresh();
        }

        private void RxSenTextClr_Click_1(object sender, EventArgs e)
        {
            rxResult.Text = "";
        }

        private void SaveInitValueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveInitValue();
        }

        private void loadInitFileToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            bool flag = false;
            
            flag = LoadRegValue();
            if (flag)
            {
                bSearchReg = false;
                searchTxt.Text = "";
                ShowAllRegisterData();
            }
        }

         private void btnTableComRefresh_Click(object sender, EventArgs e)
        {
            tableCombobox.Items.Clear();
            string[] ArrayComPortsNames = SerialPort.GetPortNames();
            if (ArrayComPortsNames.Length == 0)
            {
                //btnTxComConnect.Enabled = false;
            }
            else
            {
                Array.Sort(ArrayComPortsNames);
                for (int i = 0; i < ArrayComPortsNames.Length; i++)
                {
                    tableCombobox.Items.Add(ArrayComPortsNames[i]);
                }
                tableCombobox.Text = ArrayComPortsNames[0];
                //btnTxComConnect.Enabled = true;
            }
        }

        System.Threading.Thread CloseDown1;
        private void btnTxComConnect_Click(object sender, EventArgs e)
        {
            if (btnTxComConnect.Text == "CONNECT")
            {
                if (!serialPort1.IsOpen)
                {
                    ConnectSerial3();
                }
                Thread.Sleep(100);
                                
                if (serialPort1.IsOpen)
                {
                    btnTxComConnect.Text = "CLOSE";
                    btnTxComRefresh.Enabled = false;
                    txComboBox.Enabled = false;
                    Thread.Sleep(20);
                    //serialPort1.WriteLine("settestst 1\r"); // Owen tmp Closed
                    highlowICType = CheckICPowerType();
                    if (highlowICType == 0)
                    {
                        powerCombo.Items.Clear();
                        InitialLowPowerList();
                    }
                    else
                    {
                        powerCombo.Items.Clear();
                        InitialPowerList();
                    }
                }
            }
            else
            {
                if (serialPort1.IsOpen)
                {
                    serialPort1.WriteLine("settestst 0\r");
                    Thread.Sleep(100);
                    //serialPort1.Close();
                    CloseDown1 = new System.Threading.Thread(new System.Threading.ThreadStart(CloseSerial1OnExit));
                    CloseDown1.Start();
                }
                btnTxComConnect.Text = "CONNECT";
                btnTxComRefresh.Enabled = true;
                txComboBox.Enabled = true;
                
            }
        }
                
        private void CloseSerial1OnExit()
        {
            try
            {
                //serialPort1.DataReceived -= RxReceiveData;
                serialPort1.DiscardInBuffer();
                serialPort1.DiscardOutBuffer();
                serialPort1.Close();
            }
            catch (Exception ex)
            {
                //ShowTxLog(ex.Message + "\r\n");
            }
        }

        public void SetSyncword()
        {
            string txSyncwordHex = txSyncword.Text;
            uint intValue = (UInt32)Convert.ToInt32(txSyncwordHex, 16);
            string cmd = "cfg 7 " + intValue + "\r";
            bool res = ER4100_SendCmd(cmd);
            if (!res)
                ShowInsLog("COM PORT ERROR\r\n");
            else
                ShowInsLog("Set Syncword OK\r\n");
        }
        private void btnTxSetSyncword_Click(object sender, EventArgs e)
        {
            string txSyncwordHex = txSyncword.Text;
            uint intValue = (UInt32)Convert.ToInt32(txSyncwordHex, 16);
            string cmd = "cfg 7 " + intValue + "\r";
            bool res = ER4100_SendCmd(cmd);
            if (!res)
                ShowInsLog("COM PORT ERROR\r\n");
            else
                ShowInsLog("Set Syncword OK\r\n");
        }

        private void btnRxSetSyncword_Click(object sender, EventArgs e)
        {
            string rxSyncwordHex = rxSyncword.Text;
            uint intValue = (UInt32)Convert.ToInt32(rxSyncwordHex, 16);
            bool res = false;
            string cmd = "";

            //-------------RX OFF---------------
            cmd = "rx 0\r";
            if (isRxOldMethod)
                res = ER4100_SendCmdThread(cmd);
            else
                res = ER4100_RxSendCmd(cmd);
            // --------------------------------------
            if (!res)
                ShowRxLog("COM PORT ERROR\r\n");
            else
            {
                Thread.Sleep(100);
                //-------------Set Syncword---------------
                cmd = "cfg 7 " + intValue + "\r";
                if (isRxOldMethod)
                    res = ER4100_SendCmdThread(cmd);
                else
                    res = ER4100_RxSendCmd(cmd);
                Thread.Sleep(100);

                //-------------Set RX ON--------------
                cmd = ("rx 1 0 128 0\r"); // RX ON
                if (isRxOldMethod)
                    res = ER4100_SendCmdThread(cmd);
                else
                    res = ER4100_RxSendCmd(cmd);

                ShowRxLog("Set Syncword OK\r\n");

                rxReceivedNum = 0;
                ShowRxRcvNum(rxReceivedNum.ToString(), "");
            }
        }

        public void ShowRxRcvNum(string sNum, string sRssi)
        {
            if (this.InvokeRequired)
            {
                DelShowRxRcvNum del = new DelShowRxRcvNum(ShowRxRcvNum);
                this.Invoke(del, sNum, sRssi);
            }
            else
            {
                //txPCBPower.Text = str;
                rxrcvtbx.Text = sNum;
                rxrcvtbx.Update();
                rssiValue.Text = sRssi;
                rssiValue.Update();
            }
        }
        //public int rnum = 0;
        public string lastRSSI = "";
        public void RxReceiveData(object sender, SerialDataReceivedEventArgs e)
        {
            //string str = serialPort2.ReadExisting();
            try
            {
                string str = "";
                str = serialPort2.ReadLine();
                string sRssi = "";
                string tmp = "";
                int nowRssi = 0;
                int start = 0;
                //int stop = 0;
                if (str.Contains('#'))
                {
                    rxReceivedNum++;
                    if (str.Contains('$') && str.Contains('&'))
                    {                  
                        start = str.IndexOf("$");
                        //stop = str.IndexOf("#");
                        tmp = str.Substring((start+1), 3);
                        nowRssi = (-1) * Convert.ToInt32(tmp);
                        sRssi = nowRssi.ToString();
                        //lastRSSI = sRssi;
                        //ShowRxLog(start+" "+stop + " "+ tmp + "\r\n");
                    }                    
                }
                //else
                //    sRssi = lastRSSI;

                if (isRxSenStart)
                    ShowRxRcvNum(rxReceivedNum.ToString(), sRssi);
            }
            catch (Exception ex)
            {
                //sRssi = lastRSSI;
                //ShowRxLog(str + "\r\n");
            }
            serialPort2.DiscardInBuffer();
            //serialPort2.DiscardOutBuffer();
        }

        private void btnModeComRefresh_Click(object sender, EventArgs e)
        {
            ModeComRefresh();
        }

        private void btnModeComConnect_Click(object sender, EventArgs e)
        {
            bool res = false;
            if (btnModeComConnect.Text == "CONNECT")
            {
                if (!serialPort3.IsOpen)
                {
                    ConnectSerial4();
                }
                Thread.Sleep(100);

                if (serialPort3.IsOpen)
                {
                    btnModeComConnect.Text = "CLOSE";
                    btnModeComRefresh.Enabled = false;
                    modeCombobox.Enabled = false;
                    Thread.Sleep(20);
                    serialPort3.WriteLine("settestst 1\r");
                }
            }
            else
            {
                if (serialPort3.IsOpen)
                {
                    serialPort3.Close();
                }
                if (!serialPort3.IsOpen)
                {
                    btnModeComConnect.Text = "CONNECT";
                    btnModeComRefresh.Enabled = true;
                    modeCombobox.Enabled = true;
                    ShowModeLog(modeCombobox.Text+" Disconnected\r\n");
                }
                else
                {
                    ShowModeLog(modeCombobox.Text + " close failed\r\n");
                }
            }
        }

        private void btnModeSet_Click(object sender, EventArgs e)
        {
            int idx = modeSelectCombobox.SelectedIndex;
            string cmd = "";
            //xtapp_idle_mode = 0,
            //xtapp_deep_sleep_mode = 1,   
            //xtapp_shutdown_mode = 2,
            cmd = "pm " + idx + "\r";
            bool res = ER4100_SendModeCmd(cmd);
            string stmp = "";
            if (!res)
                ShowModeLog("COM PORT ERROR\r\n");
            else
            {
                Thread.Sleep(100);
                string modeLog = "";
                switch (idx)
                {
                    case 0: modeLog = "Set Idle Mode\r\n"; break;
                    case 1: modeLog = "Set DeepSleep Mode\r\n"; break;
                    case 2: modeLog = "Set Shutdown Mode\r\n"; break;
                }
                //stmp = serialPort3.ReadExisting();
                ShowModeLog(modeLog);
            }
        }

        private void btnModeTextClear_Click(object sender, EventArgs e)
        {
            modeTextbox.Clear();
        }

        private void btnTableConnect_Click(object sender, EventArgs e)
        {
            if (btnTableConnect.Text == "CONNECT")
            {
                if (!serialPort1.IsOpen)
                {
                    ConnectSerial2();
                }
                Thread.Sleep(100);

                if (serialPort1.IsOpen)
                {
                    btnTableConnect.Text = "CLOSE";
                    btnTableComRefresh.Enabled = false;
                    tableCombobox.Enabled = false;
                    Thread.Sleep(20);
                    serialPort1.WriteLine("settestst 1\r");
                }
            }
            else
            {
                if (serialPort1.IsOpen)
                {
                    serialPort1.Close();
                }
                btnTableConnect.Text = "CONNECT";
                btnTableComRefresh.Enabled = true;
                tableCombobox.Enabled = true;

            }
        }

        private void aboutToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            AboutForm about = new AboutForm();
            about.StartPosition = FormStartPosition.CenterParent;
            about.Show();

            if (about.StartPosition == FormStartPosition.CenterParent)
            {
                var x = Location.X + (Width - about.Width) / 2;
                var y = Location.Y + (Height - about.Height) / 2;
                about.Location = new Point(Math.Max(x, 0), Math.Max(y, 0));
            }
        }
        private void QuitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (serialPort2.IsOpen)
            {
                CloseDown2 = new System.Threading.Thread(new System.Threading.ThreadStart(CloseSerial2OnExit));
                CloseDown2.Start();
            }
            if (serialPort1.IsOpen)
            {
                //serialPort1.Close();
                CloseDown1 = new System.Threading.Thread(new System.Threading.ThreadStart(CloseSerial1OnExit));
                CloseDown1.Start();
            }

            this.Close();
        }
       
        private void rxDRCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            int modIdxLen = 1;
            switch (rxDRCombo.SelectedIndex)
            {
                case 0: modIdxLen = 1; break;   //  2M
                case 1: modIdxLen = 2; break;   //  1M
                case 2: modIdxLen = 3; break;   //  500K
                default:
                    modIdxLen = 4;
                    break;
            }
            InitialRxModIdx(modIdxLen);
        }

        private void btnClearModeLog_Click(object sender, EventArgs e)
        {
            modeTextbox.Clear();
        }

        ushort crc16_ibm(byte[] data, byte length)
        {
            ushort crc = 0xFFFF;
            byte i = 0;
            byte j = 0;
            byte temp = 0; 
            byte oper = 0;
            ushort temp_short;


            for (i = 0; i < length; i++)
            {
                oper = data[i];
                if (true)
                {
                    temp = oper;
                    oper = 0;
                    for (j = 0; j < 8; j++)
                    {
                         
                        if ((temp & 0x01)>=1)
                            oper |= (byte) (0x01 << (7 - j));
                        temp >>= 1;
                    }
                }
                crc ^= oper;
                for (j = 0; j < 8; j++)
                {
                    if ((crc & 0x0001)>=1)
                    {
                        crc = (ushort) ((crc >> 1) ^ 0xA001); // A001=8005 bit inverse
                    }
                    else
                    {
                        crc >>= 1;
                    }
                }
            }
            if (true)
            {
                temp_short = crc;
                crc = 0;
                for (i = 0; i < 16; i++)
                {
                    if ((temp_short & 0x01)>=1)
                        crc |= (ushort) (0x01 << (15 - i));
                    temp_short >>= 1;
                }
            }
            return crc;// ^ CRC_XOROUT;
        }

        static ushort ComputeCrc16Ibm(byte[] data)
        {
            ushort crc = 0x0000;
            ushort CRC16_IBM_POLY = 0xA001;
            foreach (byte b in data)
            {
                crc ^= b;
                for (int i = 0; i < 8; i++)
                {
                    if ((crc & 0x0001) != 0)
                    {
                        crc = (ushort)((crc >> 1) ^ CRC16_IBM_POLY);
                    }
                    else
                    {
                        crc >>= 1;
                    }
                }
            }
            return crc;

        }
        public void ShowPktData(int len)
        {
            byte[] datas = new byte[len];
            for (uint i = 0; i < len; i++)
                datas[i] = (byte) (i & 0xFF);

            datas[0] = (byte)len;
            datas[1] = 0x46;
            datas[2] = 0x53;
            //txResult.Text = (len+2).ToString("X2")+" ";
            
            for (int j=0;j<len; j++)
            {
                txResult.Text += datas[j].ToString("X2") + " ";
            }
            //txResult.Text += "\r\n";
            //int totalLen = len + 3;
            //byte[] data = { 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39 }; // "123456789"
            ushort crc = crc16_ibm(datas, (byte)len);
            //ushort crc = ComputeCrc16Ibm(datas);
            //txResult.Text += "CRC="+crc.ToString("X4") + "\r\n";
            txResult.Text += (crc & 0xFF).ToString("X2") + " " + (crc >> 8).ToString("X2")+"\r\n";            
        }

        public void SetPayloadProcess()
        {
            int len = 0;
            int num = 0;
            string cmd = "";
            bool addSeq = false;
            if (addSeqCheckbox.Checked)
                addSeq = true;
            else
                addSeq = false;

            if (addSeq)
            {
                cmd = "cfg 23 1\r";    // addSeq = true (1)
                serialPort1.WriteLine(cmd);
                Thread.Sleep(50);
                cmd = "cfg 25 0\r";    // seqNumber = 0 (reset)
                serialPort1.WriteLine(cmd);
                Thread.Sleep(50);
            }
            else
            {
                cmd = "cfg 23 0\r";    // addSeq = false (0)
                serialPort1.WriteLine(cmd);
                Thread.Sleep(50);
            }
            try
            {
                //len = Convert.ToInt32(randomLen.Text);
                //num = Convert.ToInt32(numOfPkt.Text);
                //txResult.Text += "tmpArray Len = " + tmpArray.Count + "\r\n";
                StringBuilder sb = new StringBuilder();
                foreach (byte b in tmpArray)
                {
                    sb.AppendFormat("{0:X2} ", b); // 轉成 2 位大寫 HEX，加空格
                }
                //txResult.Text += sb.ToString().Trim();

            }
            catch (Exception ex)
            {
                //txResult.Text += "len <= 125";
                ShowInsLog("len is over range; len <= 125");
            }
            int crcValue = CRC_Calculation();
            byte[] bytes = new byte[2];
            bytes[0] = (byte)((crcValue >> 8) & 0xFF);
            bytes[1] = (byte)(crcValue & 0xFF);
            string hexString = $"{bytes[0]:X2} {bytes[1]:X2}";
            //txResult.Text += "\r\nCRC=" + hexString + "\r\n";
            int sendSize = 0;
            if (serialPort1.IsOpen)
            {
                cmd = "cfg 16 ";    // Set payload
                if ((addSeq) && (tmpArray[0]>123))
                {
                    tmpArray[0] = 123;
                    sendSize = 124;
                }
                else
                {
                    sendSize = tmpArray.Count;
                }
                for (int i = 0; i < sendSize; i++)
                {
                    cmd += tmpArray[i].ToString() + " ";
                }
                cmd += "\r";
                serialPort1.WriteLine(cmd);
                Thread.Sleep(100);
                string stmp = serialPort1.ReadLine();
                //txResult.Text += stmp + "\r\n";
                ShowInsLog("Set Payload OK\r\n");
            }
            else
            {
                txResult.Text = "COM PORT NOT READY!\r\n";
            }


        }
        private void btnSetPayload_Click(object sender, EventArgs e)
        {
            SetPayloadProcess();
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private const int MaxHexChars = 125 * 2;
        private bool isEditing = false;
        private List<byte> tmpArray = new List<byte>();
        
        private void dataTxt_TextChanged(object sender, EventArgs e)
        {
            if (!randomCheckbox.Checked)
            {
                if (isEditing) return;
                isEditing = true;

                // Step 1: 移除非十六進位字元並轉大寫
                string raw = Regex.Replace(dataTxt.Text.ToUpper(), @"[^0-9A-F]", "");

                // Step 2: 限制最多 125 個 hex 字元
                if (raw.Length > MaxHexChars)
                {
                    raw = raw.Substring(0, MaxHexChars);
                    System.Media.SystemSounds.Beep.Play(); // 警告音
                }

                // Step 3: 重新格式化為每2位一組加空格
                StringBuilder formatted = new StringBuilder();
                tmpArray.Clear();
                int fullByteCount = raw.Length / 2;

                for (int i = 0; i < raw.Length; i++)
                {
                    formatted.Append(raw[i]);
                    if (i % 2 == 1 && i != raw.Length - 1)
                        formatted.Append(" ");
                }

                // Step 4: 將格式化後的字串寫回 TextBoxInput
                dataTxt.Text = formatted.ToString();
                dataTxt.SelectionStart = dataTxt.Text.Length;

                // Step 5: 將完整兩位一組的 hex 字串轉成 byte
                try
                {
                    tmpArray.Add(0);
                    for (int i = 0; i < fullByteCount * 2; i += 2)
                    {
                        string byteStr = raw.Substring(i, 2);
                        byte b = Convert.ToByte(byteStr, 16);
                        tmpArray.Add(b);
                    }
                }
                catch
                {
                    // 忽略格式錯誤
                }
                tmpArray[0] = (byte)(tmpArray.Count - 1);
                // Step 6: 更新長度與 HEX 顯示
                lenOfHex.Text = tmpArray[0].ToString();   //tmpArray.Count.ToString();

                StringBuilder hexOutput = new StringBuilder();
                foreach (byte b in tmpArray)
                {
                    hexOutput.AppendFormat("{0:X2} ", b);
                }
                //txResult.Text = hexOutput.ToString().Trim();
                isEditing = false;
            }
            
        }
        static uint ReverseBits(uint value)
        {
            uint result = 0;

            for (int i = 0; i < 32; i++)
            {
                result <<= 1;
                result |= (value & 1);
                value >>= 1;
            }
            return result;
        }

        public string hexReverse(string hexInput)
        {
            string hexResult = "";
            uint value = Convert.ToUInt32(hexInput, 16);
            uint reversed = ReverseBits(value);
            hexResult = reversed.ToString("X8");
            return hexResult;
        }
        private void btnCalCrc_Click(object sender, EventArgs e)
        {
            
            string hexInput = txSyncword.Text;
            string hexResult = hexReverse(txSyncword.Text);
            txResult.Text = "0x"+hexInput + "=>" + hexResult;
            
            /*
            int crcValue = 0;
            byte[] bytes = new byte[2];
            crcValue = CRC_Calculation();
            bytes[0] = (byte)((crcValue >> 8) & 0xFF);
            bytes[1] = (byte)(crcValue & 0xFF);            
            string hexString = $"{bytes[0]:X2} {bytes[1]:X2}";
            txResult.Text += "\r\nCRC=" + hexString+"\r\n";
            */

        }
        
        public int CRC_Calculation()
        {
            int crc = 0xFFFF;
            int i = 0;
            int j = 0;
            int temp = 0, oper;
            int temp_short;

            for (i = 0; i < tmpArray.Count; i++)
            {
                oper = tmpArray[i];
                if (true)
                {
                    temp = oper;
                    oper = 0;
                    for (j = 0; j < 8; j++)
                    {
                        if ((temp & 0x01)>0)
                            oper |= 0x01 << (7 - j);
                        temp >>= 1;
                    }
                }
                crc ^= oper;
                for (j = 0; j < 8; j++)
                {
                    if ((crc & 0x0001)>0)
                    {
                        crc = (crc >> 1) ^ 0xA001; // A001=8005 bit inverse
                    }
                    else
                    {
                        crc >>= 1;
                    }
                }
            }
            if (true)
            {
                temp_short = crc;
                crc = 0;
                for (i = 0; i < 16; i++)
                {
                    if ((temp_short & 0x01)>0)
                        crc |= 0x01 << (15 - i);
                    temp_short >>= 1;
                }
            }
            return crc;
        }

        public void DisableSetting()
        {
            if (this.InvokeRequired)
            {
                DelDisableSetting del = new DelDisableSetting(DisableSetting);
                this.Invoke(del);
            }
            else
            {
                txFreqText.Enabled = false;
                txFreqText.Update();
                txDRCombo.Enabled = false;
                txDRCombo.Update();
                freqDev.Enabled = false;
                freqDev.Update();
                txModCombo.Enabled = false;
                txModCombo.Update();
                powerCombo.Enabled = false;
                powerCombo.Update();
                txSyncword.Enabled = false;
                txSyncword.Update();
                infiniteCheckbox.Enabled = false;
                infiniteCheckbox.Update();
                addSeqCheckbox.Enabled = false;
                addSeqCheckbox.Update(); 
                randomCheckbox.Enabled = false;
                randomCheckbox.Update();
                btnRandomGenerate.Enabled = false;
                btnRandomGenerate.Update();
                //numOfPkt.Enabled = false;
                randomLen.Enabled = false;
                randomLen.Update();
                dataTxt.Enabled = false;
                dataTxt.Update();
            }
            

        }

        public void EnableSetting()
        {
            txFreqText.Enabled = true;
            txDRCombo.Enabled = true;
            freqDev.Enabled = true;
            txModCombo.Enabled = true;
            powerCombo.Enabled = true;
            txSyncword.Enabled = true;
            infiniteCheckbox.Enabled = true;
            addSeqCheckbox.Enabled = true;
            randomCheckbox.Enabled = true;
            btnRandomGenerate.Enabled = true;
            numOfPkt.Enabled = true;
            randomLen.Enabled = true;
            if (randomCheckbox.Checked == false)
            {
                dataTxt.Enabled = true;
                dataTxt.Update();
            }
                
        }
        public void InfiniteStop()
        {
            if (serialPort1.IsOpen)
                serialPort1.Write("t");
        }
        private void btnStop_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
                InfiniteStop();
            else
                txResult.Text += "COMPORT ERROR!\r\n";
        }
        public void InfiniteStart()
        {            
            serialPort1.Write("cfg 21\r");
            Thread.Sleep(200);
        }
        public void PacketSend(int num)
        {
            btnInfiniteStart.Enabled = false;
            string cmd = "cfg 14 "+1 +"\r";
            ShowInsLog("Packet Send\r\n");
            for (int i = 0; i < num; i++)
            {
                serialPort1.WriteLine(cmd);
                Thread.Sleep(100);
            }
            ShowInsLog("Packet Send Finished\r\n");
            btnInfiniteStart.Enabled = true;
            EnableSetting();
        }
        private void btnInfiniteStart_Click(object sender, EventArgs e)
        {
            int lenOfHexTxt = Convert.ToInt32(lenOfHex.Text);
            int lenOfRandomTxt = Convert.ToInt32(randomLen.Text);
            //int size = tmpArray.Count;
            //ShowInsLog("size = "+size+"\r\n");
            bool isEmpty = false;
            if (string.IsNullOrWhiteSpace(dataTxt.Text))
            {
                isEmpty = true;
            }
            int num = 0;
            if (((lenOfHexTxt <= 0) && (lenOfRandomTxt <=0)) || (isEmpty))
            {
                ShowInsLog("ERROR: The Length of payload is 0 or payload is empty!\r\n");
                //ShowInsLog("=================================\r\n");
                return;
            }
                
            bool res = false;
            //btnInfiniteStart.Enabled = false;
            if (serialPort1.IsOpen)
            {
                res = ER4100_SetParameter();
                if (res)
                {
                    SetPayloadProcess();
                    if (infiniteCheckbox.Checked)
                    {
                        //btnInfiniteStart.Text = "STOP";                    
                        btnInfiniteStart.Enabled = false;
                        btnSendStop.Enabled = true;
                        ShowInsLog("Packet Send\r\n");

                        DisableSetting();
                        InfiniteStart();
                    }
                    else
                    {
                        num = Convert.ToInt32(numOfPkt.Text);
                        if (num <= 200 && num > 0)
                        {
                            DisableSetting();
                            PacketSend(num);
                        }
                        else
                            ShowInsLog("num need to be 0<num<=200");
                    }
                    
                }               
                
            }
            else
            {
                txResult.Text += "COMPORT ERROR!\r\n";
                EnableSetting();
            }
                
        }

        private void infiniteCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (infiniteCheckbox.Checked)
            {
                numOfPkt.Enabled = false;
            }
            else
                numOfPkt.Enabled = true;
        }

        public void HexGenerate()
        {
            int byteLength = 0;
            dataTxt.Clear();
            try
            {
                byteLength = Convert.ToInt32(randomLen.Text);
            }
            catch (Exception ex)
            {
                ;
            }
            if (byteLength > 0 && byteLength <= 125)
            {
                byte[] buffer = new byte[byteLength];
                Random rand = new Random();
                rand.NextBytes(buffer);
                tmpArray.Clear();
                tmpArray.Add((byte)byteLength);  // 注意轉型為 byte
                tmpArray.AddRange(buffer);

                StringBuilder sb = new StringBuilder(byteLength * 3); // 每個 byte 占 "?? " 共3個字元

                foreach (byte b in buffer)
                {
                    sb.AppendFormat("{0:X2} ", b); // 轉成兩位大寫十六進位
                }

                dataTxt.Text = sb.ToString().Trim(); // 移除最後一個空格
            }
            else
            {
                ShowInsLog("Payload length: 0<Len<=125\r\n");
            }
        }
        private void randomCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (randomCheckbox.Checked) {
                dataTxt.Clear();
                dataTxt.Enabled = false;
                dataTxt.BackColor = Color.White;
                dataTxt.Update();
                tmpArray.Clear();
                btnRandomGenerate.ForeColor = Color.SteelBlue;
                btnRandomGenerate.BackColor = Color.White;
                //btnRandomGenerate.Font = new Font("Arial", 12, FontStyle.Bold);
                btnRandomGenerate.Visible = true;
                randomLen.Visible = true;
                lenOfHex.Text = "0";
                lenOfHex.BackColor = Color.White;
                lenOfHex.Update();
                randomLen.Text = "0";
                randomLenLable.Visible = true;
                lenOfHex.Visible = false;
                lenOfTxtLable.Visible = false;  
                
            }
            else
            {
                btnRandomGenerate.Visible = false;
                btnRandomGenerate.ForeColor = Color.White;
                btnRandomGenerate.BackColor = Color.WhiteSmoke;
                randomLen.Visible = false;
                randomLenLable.Visible = false;
                //dataTxt.Enabled = true;
                lenOfHex.Visible = true;
                lenOfHex.Text = "0";
                randomLen.Text = "0";
                lenOfTxtLable.Visible = true;
                dataTxt.BackColor = Color.White;
                dataTxt.Enabled = true;
                dataTxt.Update();
                dataTxt.Clear();
                tmpArray.Clear();
            }

        }
        
        private void btnRandomGenerate_Click(object sender, EventArgs e)
        {
            if (randomCheckbox.Checked)
            {
                HexGenerate();
            }
        }

        private void btnSendStop_Click(object sender, EventArgs e)
        {
            if (infiniteCheckbox.Checked)
            {
                InfiniteStop();
                //btnInfiniteStart.Text = "START";
            }
            btnSendStop.Enabled = false;
            btnInfiniteStart.Enabled = true;
            ShowInsLog("Packet Stop\r\n");
            EnableSetting();
        }
        public static string cutTitle(string t, int len)
        {
            return t.Substring(0, len);
        }
        public string ChooseINIFile()
        {
            //System.IO.Path.GetDirectoryName(Application.ExecutablePath)
            //Environment.GetFolderPath(Environment.SpecialFolder.Personal); 
            //Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.InitialDirectory = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            fileDialog.Filter = "ini file|*.ini";
            fileDialog.DefaultExt = ".ini";
            string fileStr = "";

            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                fileStr = fileDialog.FileName;               
            }

            return fileStr;
        }

        public bool LoadIniFile(string fileStr)
        {
            bool res = false;
            var MyIni = new IniFile3(fileStr);
            string ini_freq = "868";
            double ini_datarate = 10.0;
            string ini_freqdev = "8.5";
            string ini_power = "23";
            string ini_syncword = "12345678";
            string ini_comport = "";
            if (MyIni.KeyExists("COM", "COMPORT"))
            {
                ini_comport = MyIni.Read("COM", "COMPORT");
                txComboBox.Text = ini_comport;
            }

            if (MyIni.KeyExists("FREQUENCY", "PARAMETER"))
            {
                ini_freq = MyIni.Read("FREQUENCY", "PARAMETER");
                txFreqText.Text = ini_freq;
            }

            if (MyIni.KeyExists("DATARATE", "PARAMETER"))
            {
                ini_datarate = Convert.ToDouble(MyIni.Read("DATARATE", "PARAMETER"));
                for (int i = 0; i < drList.Length; i++)
                {
                    if (Convert.ToDouble(drList[i]) == ini_datarate)
                    {
                        txDRCombo.SelectedIndex = i;
                        break;
                    }
                }
            }
                
            if (MyIni.KeyExists("FREQDEV", "PARAMETER"))
            {
                ini_freqdev = MyIni.Read("FREQDEV", "PARAMETER");
                freqDev.Text = ini_freqdev;
            }
                
            if (MyIni.KeyExists("POWER", "PARAMETER"))
            {
                ini_power = MyIni.Read("POWER", "PARAMETER");
                powerCombo.Text = ini_power;
            }
                
            if (MyIni.KeyExists("SYNCWORD", "PARAMETER"))
            {
                ini_syncword = MyIni.Read("SYNCWORD", "PARAMETER");
                txSyncword.Text = ini_syncword;
            }
                
            return res;
        }
        private void loadIniFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string iniFileLoc = ChooseINIFile();
            if (iniFileLoc.Equals("WRONG"))
            {
                ShowInsLog("**********************************\r\n");
                ShowInsLog("********* WRONG INI FILE *********\r\n");
                ShowInsLog("**********************************\r\n");
            }
            else
            {
                ShowInsLog("Choose ini File =" + iniFileLoc + "\r\n");
                LoadIniFile(iniFileLoc);
            }
        }

        public void SaveDataToIni(string fileStr)
        {

            var MyIni = new IniFile3(fileStr);
            MyIni.Write("COM", txComboBox.Text, "COMPORT");
            MyIni.Write("FREQUENCY", txFreqText.Text, "PARAMETER");
            MyIni.Write("DATARATE", txDRCombo.Text, "PARAMETER");
            MyIni.Write("FREQDEV", freqDev.Text, "PARAMETER");
            MyIni.Write("POWER", powerCombo.Text, "PARAMETER");
            MyIni.Write("SYNCWORD", txSyncword.Text, "PARAMETER");
            //ini.Write("設定", "語言", "中文");
        }
        private void saveIniFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "INI files (*.ini)|*.ini";
            saveFileDialog.Title = "選擇要儲存的 INI 檔案";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string iniFilePath = saveFileDialog.FileName;
                if (File.Exists(iniFilePath))
                {
                    File.WriteAllText(iniFilePath, string.Empty);
                }
                //IniFile3 ini = new IniFile3(iniFilePath);

                // 寫入參數
                //ini.Write("設定", "使用者名稱", "JohnDoe");
                //ini.Write("設定", "語言", "中文");
                SaveDataToIni(iniFilePath);
            }
        }

        /* Hold 1
        private void dataTxt_TextChanged(object sender, EventArgs e)
        {
            string hexString = dataTxt.Text.Replace(" ", ""); // 移除空格
            tmpArray.Clear();

            if (hexString.Length % 2 != 0)
            {
                // 如果是奇數長度，先暫時不要轉換，直到輸入完整兩個字元
                lenOfTrans.Text = tmpArray.Count.ToString();
                return;
            }

            try
            {
                for (int i = 0; i < hexString.Length; i += 2)
                {
                    string byteString = hexString.Substring(i, 2);
                    byte value = Convert.ToByte(byteString, 16);
                    tmpArray.Add(value);
                }

                // 更新長度顯示
                lenOfTrans.Text = tmpArray.Count.ToString();
            }
            catch (FormatException)
            {
                MessageBox.Show("請輸入有效的16進位字串（例如：0A1B2C）", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        } */


        /* Hold 2
        private void dataTxt_TextChanged(object sender, EventArgs e)
        {         
            if (isEditing) return;
            isEditing = true;

            // Step 1: 移除非十六進位字元並轉大寫
            string raw = Regex.Replace(dataTxt.Text.ToUpper(), @"[^0-9A-F]", "");
            StringBuilder formatted = new StringBuilder();
            tmpArray.Clear();

            // Step 2: 將每兩位加空格，並同時填入 tmpArray
            int fullByteCount = raw.Length / 2;

            for (int i = 0; i < raw.Length; i++)
            {
                formatted.Append(raw[i]);
                if ((i % 2 == 1) && (i != raw.Length - 1))
                    formatted.Append(" ");
            }

            // Step 3: 將格式化後的字串寫回 TextBoxInput
            dataTxt.Text = formatted.ToString();
            dataTxt.SelectionStart = dataTxt.Text.Length;

            // Step 4: 將完整的兩位一組轉成 byte 存入 tmpArray
            try
            {
                for (int i = 0; i < fullByteCount * 2; i += 2)
                {
                    string byteStr = raw.Substring(i, 2);
                    byte b = Convert.ToByte(byteStr, 16);
                    tmpArray.Add(b);
                }
            }
            catch
            {
                // 忽略錯誤（例如格式錯），但你也可以選擇提示
            }

            // Step 5: 更新顯示長度與 HEX 輸出
            lenOfTrans.Text = tmpArray.Count.ToString();
            
            StringBuilder hexOutput = new StringBuilder();
            foreach (byte b in tmpArray)
            {
                hexOutput.AppendFormat("{0:X2} ", b);
            }
            txResult.Text = hexOutput.ToString().Trim();

            isEditing = false;
        }
        */
        // string to hexstring
        //string prefixedHex = hexTxt.Text;
        //uint intValue = (UInt32)Convert.ToInt32(prefixedHex, 16);
        //txtValue.Text += "0x"+prefixedHex +"= " + intValue + "\r\n";
    }
}
